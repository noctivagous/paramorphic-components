import React, { useEffect, useMemo, useRef, useState } from "react";

// ---------- Types ----------
type Pos = { q: number; r: number };
type Axial = { q: number; r: number };

type TilingDir = {
  name: string;
  dq: number; // offset delta for square, axial delta for hex (stored as axial)
  dr: number;
  axial: Axial;
  angle: number;
  isOrthogonal?: boolean;
  isDiagonal?: boolean;
};

type TilingDef = {
  id: "square4" | "square8" | "hexH" | "hexV";
  name: string;
  shape: "square" | "hex";
  style: "2color" | "3color";
  directions: TilingDir[];
  directionMap: Record<string, TilingDir>;
  leaps: { name: string; offsets: { dq: number; dr: number; axial: Axial }[] }; // knight
};

type MoveKind =
  | { type: "step"; dir: string; count?: number }
  | { type: "slide"; dir: string; min?: number; max?: number }
  | { type: "leap"; offsets: { dq: number; dr: number; axial?: Axial }[] }
  | { type: "pawn"; forward: string | string[]; captureDirs: string[]; firstDouble?: boolean }
  | { type: "place"; anywhere?: boolean };

type MoveRule = {
  pieceType: string;
  moves: MoveKind[];
  capture?: "move" | "captureOnly" | "both";
  jumpOver?: boolean;
  onMove?: { promoteTo?: string[]; ifInRegion?: string; chain?: boolean };
  onCapture?: { remove?: boolean; chain?: boolean };
  requires?: { darkOnly?: boolean };
};

type TurnRule =
  | { type: "alternating"; order: string[]; first: string }
  | { type: "free" }
  | { type: "samePlayerIfCapture"; order: string[]; first: string };

type OutcomeCondition =
  | { kind: "line"; player: string; count: number; directions?: string[] | "any"; regions?: string[] | "all"; id?: string }
  | { kind: "captureAll"; player?: string; target?: string; winFor?: string; id?: string }
  | { kind: "noMoves"; player: string; id?: string }
  | { kind: "kingCaptured"; player: string; id?: string }
  | { kind: "reachRow"; player: string; regionId: string; id?: string }
  | { kind: "boardFull"; draw?: boolean; id?: string }
  | { kind: "fillRegions"; constraint?: string; id?: string }
  | { kind: "topReached"; row: number; id?: string };

type Region = { id: string; cells: Pos[]; type: "row" | "col" | "box" | "edge" | "track" | "word" | "custom"; color?: string };

type Guest =
  | { kind: "Path"; state: { points: { x: number; y: number }[] } }
  | { kind: "Tree"; state: { rootId: string } }
  | { kind: "Grid"; state: { occupants: Occupant[]; width: number; height: number } }
  | { kind: "Logic"; state: { triples: LogicTriple[] } };

type Occupant = {
  id: string;
  anchor: Pos;
  span: Pos[]; // offsets from anchor
  type: string;
  data: any;
  tags: string[];
  guest?: Guest;
  z?: number;
};

type LogicTriple = { id: string; s: string; p: string; o: string };

type RuleSet = {
  id: string;
  setup: { width: number; height: number; description: string };
  moves: MoveRule[];
  turns: TurnRule;
  outcomes: OutcomeCondition[];
  end: { condition: string; action: string };
  regions: Region[];
  gravity?: { direction: string; after: "move" | "always" };
};

type Toggles = { gravity: boolean; diagonal: boolean; sliding: boolean; wrapping: boolean; chainCapture: boolean };

// ---------- Tiling helpers ----------
function oddROffsetToAxial(col: number, row: number): Axial {
  const q = col - ((row - (row & 1)) >> 1);
  const r = row;
  return { q, r };
}
function axialToOddROffset(q: number, r: number): Pos {
  const col = q + ((r - (r & 1)) >> 1);
  const row = r;
  return { q: col, r: row };
}
function oddQOffsetToAxial(col: number, row: number): Axial {
  const q = col;
  const r = row - ((col - (col & 1)) >> 1);
  return { q, r };
}
function axialToOddQOffset(q: number, r: number): Pos {
  const col = q;
  const row = r + ((q - (q & 1)) >> 1);
  return { q: col, r: row };
}
function offsetToAxial(pos: Pos, tilingId: string): Axial {
  if (tilingId === "hexH") return oddROffsetToAxial(pos.q, pos.r);
  if (tilingId === "hexV") return oddQOffsetToAxial(pos.q, pos.r);
  return { q: pos.q, r: pos.r };
}
function axialToOffset(ax: Axial, tilingId: string): Pos {
  if (tilingId === "hexH") return axialToOddROffset(ax.q, ax.r);
  if (tilingId === "hexV") return axialToOddQOffset(ax.q, ax.r);
  return { q: ax.q, r: ax.r };
}
function hexDistance(a: Axial, b: Axial) {
  return (Math.abs(a.q - b.q) + Math.abs(a.q + a.r - b.q - b.q - b.r) + Math.abs(a.r - b.r)) / 2;
}
function makeId() { return Math.random().toString(36).slice(2, 9); }

// ---------- Build tilings ----------
function buildTilings(): Record<string, TilingDef> {
  const square4Dirs: TilingDir[] = [
    { name: "N", dq: 0, dr: -1, axial: { q: 0, r: -1 }, angle: 0, isOrthogonal: true },
    { name: "S", dq: 0, dr: 1, axial: { q: 0, r: 1 }, angle: 180, isOrthogonal: true },
    { name: "E", dq: 1, dr: 0, axial: { q: 1, r: 0 }, angle: 90, isOrthogonal: true },
    { name: "W", dq: -1, dr: 0, axial: { q: -1, r: 0 }, angle: 270, isOrthogonal: true },
  ];
  const square8Dirs: TilingDir[] = [
    ...square4Dirs,
    { name: "NE", dq: 1, dr: -1, axial: { q: 1, r: -1 }, angle: 45, isDiagonal: true },
    { name: "NW", dq: -1, dr: -1, axial: { q: -1, r: -1 }, angle: 315, isDiagonal: true },
    { name: "SE", dq: 1, dr: 1, axial: { q: 1, r: 1 }, angle: 135, isDiagonal: true },
    { name: "SW", dq: -1, dr: 1, axial: { q: -1, r: 1 }, angle: 225, isDiagonal: true },
  ];
  // hexH pointy-top odd-r: true E/W exists
  const hexHDirs: TilingDir[] = [
    { name: "E", dq: 1, dr: 0, axial: { q: 1, r: 0 }, angle: 0, isOrthogonal: true },
    { name: "W", dq: -1, dr: 0, axial: { q: -1, r: 0 }, angle: 180, isOrthogonal: true },
    { name: "NE", dq: 1, dr: -1, axial: { q: 1, r: -1 }, angle: 60, isDiagonal: true },
    { name: "NW", dq: 0, dr: -1, axial: { q: 0, r: -1 }, angle: 300, isDiagonal: true },
    { name: "SE", dq: 0, dr: 1, axial: { q: 0, r: 1 }, angle: 120, isDiagonal: true },
    { name: "SW", dq: -1, dr: 1, axial: { q: -1, r: 1 }, angle: 240, isDiagonal: true },
  ];
  // hexV flat-top odd-q: true N/S, no E/W — correct geometry
  const hexVDirs: TilingDir[] = [
    { name: "N", dq: 0, dr: -1, axial: { q: 0, r: -1 }, angle: 0, isOrthogonal: true },
    { name: "S", dq: 0, dr: 1, axial: { q: 0, r: 1 }, angle: 180, isOrthogonal: true },
    { name: "NE", dq: 1, dr: -1, axial: { q: 1, r: -1 }, angle: 45, isDiagonal: true },
    { name: "SE", dq: 1, dr: 0, axial: { q: 1, r: 0 }, angle: 135, isDiagonal: true },
    { name: "SW", dq: -1, dr: 1, axial: { q: -1, r: 1 }, angle: 225, isDiagonal: true },
    { name: "NW", dq: -1, dr: 0, axial: { q: -1, r: 0 }, angle: 315, isDiagonal: true },
  ];

  const squareKnightOffsets = [
    { dq: 2, dr: 1, axial: { q: 2, r: 1 } }, { dq: 1, dr: 2, axial: { q: 1, r: 2 } },
    { dq: -1, dr: 2, axial: { q: -1, r: 2 } }, { dq: -2, dr: 1, axial: { q: -2, r: 1 } },
    { dq: -2, dr: -1, axial: { q: -2, r: -1 } }, { dq: -1, dr: -2, axial: { q: -1, r: -2 } },
    { dq: 1, dr: -2, axial: { q: 1, r: -2 } }, { dq: 2, dr: -1, axial: { q: 2, r: -1 } },
  ];
  const hexKnightOffsets: { dq: number; dr: number; axial: Axial }[] = [
    { dq: 0, dr: 0, axial: { q: 2, r: 0 } }, { dq: 0, dr: 0, axial: { q: 2, r: -1 } },
    { dq: 0, dr: 0, axial: { q: 2, r: -2 } }, { dq: 0, dr: 0, axial: { q: 1, r: -2 } },
    { dq: 0, dr: 0, axial: { q: 0, r: -2 } }, { dq: 0, dr: 0, axial: { q: -1, r: -1 } },
    { dq: 0, dr: 0, axial: { q: -2, r: 0 } }, { dq: 0, dr: 0, axial: { q: -2, r: 1 } },
    { dq: 0, dr: 0, axial: { q: -2, r: 2 } }, { dq: 0, dr: 0, axial: { q: -1, r: 2 } },
    { dq: 0, dr: 0, axial: { q: 0, r: 2 } }, { dq: 0, dr: 0, axial: { q: 1, r: 1 } },
  ].map(o => ({ dq: 0, dr: 0, axial: o.axial })); // dq/dr unused for hex, axial matters

  const mk = (id: any, name: string, shape: any, style: any, dirs: TilingDir[], leaps: any): TilingDef => {
    const map: Record<string, TilingDir> = {};
    dirs.forEach(d => map[d.name] = d);
    return { id, name, shape, style, directions: dirs, directionMap: map, leaps: { name: "knight", offsets: leaps } };
  };

  return {
    square4: mk("square4", "SQUARE-4 (von Neumann)", "square", "2color", square4Dirs, squareKnightOffsets),
    square8: mk("square8", "SQUARE-8 (Moore)", "square", "2color", square8Dirs, squareKnightOffsets),
    hexH: mk("hexH", "HEX-H pointy-top odd-r — true E/W", "hex", "3color", hexHDirs, hexKnightOffsets),
    hexV: mk("hexV", "HEX-V flat-top odd-q — true N/S, no E/W", "hex", "3color", hexVDirs, hexKnightOffsets),
  };
}
const TILINGS = buildTilings();
const TILINGS_LIST = Object.values(TILINGS);

// ---------- Tiling utils ----------
function getTiling(id: string): TilingDef { return (TILINGS as any)[id] || TILINGS.square8; }

function addPosByDir(pos: Pos, dirName: string, steps: number, tiling: TilingDef, width: number, height: number, wrapping: boolean): Pos | null {
  const d = tiling.directionMap[dirName];
  if (!d) return null;
  if (tiling.shape === "square") {
    let nq = pos.q + d.dq * steps;
    let nr = pos.r + d.dr * steps;
    if (wrapping) { nq = ((nq % width) + width) % width; nr = ((nr % height) + height) % height; }
    else if (nq < 0 || nq >= width || nr < 0 || nr >= height) return null;
    return { q: nq, r: nr };
  } else {
    const ax = offsetToAxial(pos, tiling.id);
    const nAx = { q: ax.q + d.axial.q * steps, r: ax.r + d.axial.r * steps };
    const off = axialToOffset(nAx, tiling.id);
    let nq = off.q, nr = off.r;
    if (wrapping) { nq = ((nq % width) + width) % width; nr = ((nr % height) + height) % height; }
    else if (nq < 0 || nq >= width || nr < 0 || nr >= height) return null;
    return { q: nq, r: nr };
  }
}

function applyOffset(pos: Pos, off: { dq: number; dr: number; axial?: Axial }, tiling: TilingDef, width: number, height: number, wrapping: boolean): Pos | null {
  if (tiling.shape === "square") {
    let nq = pos.q + off.dq;
    let nr = pos.r + off.dr;
    if (wrapping) { nq = ((nq % width) + width) % width; nr = ((nr % height) + height) % height; }
    else if (nq < 0 || nq >= width || nr < 0 || nr >= height) return null;
    return { q: nq, r: nr };
  } else {
    const ax = offsetToAxial(pos, tiling.id);
    const add = off.axial || { q: off.dq, r: off.dr };
    const nAx = { q: ax.q + add.q, r: ax.r + add.r };
    const offPos = axialToOffset(nAx, tiling.id);
    let nq = offPos.q, nr = offPos.r;
    if (wrapping) { nq = ((nq % width) + width) % width; nr = ((nr % height) + height) % height; }
    else if (nq < 0 || nq >= width || nr < 0 || nr >= height) return null;
    return { q: nq, r: nr };
  }
}

function lineCells(start: Pos, dirName: string, count: number, tiling: TilingDef, width: number, height: number): Pos[] {
  const cells: Pos[] = [start];
  let cur = start;
  for (let i = 1; i < count; i++) {
    const nxt = addPosByDir(cur, dirName, 1, tiling, width, height, false);
    if (!nxt) break;
    cells.push(nxt);
    cur = nxt;
  }
  return cells;
}

function rotateSpan(span: Pos[], steps: number, tiling: TilingDef): Pos[] {
  if (steps === 0) return span;
  if (tiling.shape === "square") {
    // 90 deg rotation
    let cur = span;
    for (let s = 0; s < (steps % 4); s++) {
      cur = cur.map(p => ({ q: -p.r, r: p.q }));
    }
    return cur;
  } else {
    // hex 60 deg rotation using axial
    return span.map(p => {
      // p as offset from anchor, convert to axial, rotate
      const ax = offsetToAxial({ q: p.q, r: p.r }, tiling.id);
      // axial rotation 60 deg: (q,r) -> (-r, q+r)
      let q = ax.q, r = ax.r;
      for (let i = 0; i < (steps % 6); i++) {
        const nq = -r;
        const nr = q + r;
        q = nq; r = nr;
      }
      const off = axialToOffset({ q, r }, tiling.id);
      return { q: off.q, r: off.r };
    });
  }
}

function getOccupiedCells(occ: Occupant): Pos[] {
  return [{ q: occ.anchor.q, r: occ.anchor.r }, ...occ.span.map(s => ({ q: occ.anchor.q + s.q, r: occ.anchor.r + s.r }))];
}

function buildOccupancyMap(occupants: Occupant[]): Map<string, Occupant> {
  const m = new Map<string, Occupant>();
  occupants.forEach(o => {
    getOccupiedCells(o).forEach(c => m.set(`${c.q},${c.r}`, o));
  });
  return m;
}

function occupantAtCell(pos: Pos, occupants: Occupant[]): Occupant | null {
  for (const o of occupants) {
    const cells = getOccupiedCells(o);
    if (cells.some(c => c.q === pos.q && c.r === pos.r)) return o;
  }
  return null;
}

function isCellOccupied(pos: Pos, occupants: Occupant[]): boolean {
  return !!occupantAtCell(pos, occupants);
}

// ---------- Regions ----------
function makeEdgeRegions(width: number, height: number): Region[] {
  const top: Region = { id: "edge-top", cells: Array.from({ length: width }, (_, q) => ({ q, r: 0 })), type: "edge" };
  const bottom: Region = { id: "edge-bottom", cells: Array.from({ length: width }, (_, q) => ({ q, r: height - 1 })), type: "edge" };
  const left: Region = { id: "edge-left", cells: Array.from({ length: height }, (_, r) => ({ q: 0, r })), type: "edge" };
  const right: Region = { id: "edge-right", cells: Array.from({ length: height }, (_, r) => ({ q: width - 1, r })), type: "edge" };
  return [top, bottom, left, right];
}

function makeSudokuRegions(): Region[] {
  const regions: Region[] = [];
  for (let r = 0; r < 9; r++) regions.push({ id: `row-${r}`, cells: Array.from({ length: 9 }, (_, c) => ({ q: c, r })), type: "row" });
  for (let c = 0; c < 9; c++) regions.push({ id: `col-${c}`, cells: Array.from({ length: 9 }, (_, rr) => ({ q: c, r: rr })), type: "col" });
  for (let br = 0; br < 3; br++) for (let bc = 0; bc < 3; bc++) {
    const cells: Pos[] = [];
    for (let dr = 0; dr < 3; dr++) for (let dc = 0; dc < 3; dc++) cells.push({ q: bc * 3 + dc, r: br * 3 + dr });
    regions.push({ id: `box-${br}-${bc}`, cells, type: "box" });
  }
  return regions;
}

function makeTrackRegions(width: number, height: number): Region[] {
  return Array.from({ length: height }, (_, r) => ({ id: `track-${r}`, cells: Array.from({ length: width }, (_, q) => ({ q, r })), type: "track" }));
}

function isPosInRegion(pos: Pos, region: Region): boolean {
  return region.cells.some(c => c.q === pos.q && c.r === pos.r);
}

// ---------- Move engine (generic, no hard-coded id) ----------
function getValidMoves(
  occ: Occupant,
  occupants: Occupant[],
  tiling: TilingDef,
  ruleSet: RuleSet,
  width: number,
  height: number,
  toggles: Toggles,
  logicTriples: LogicTriple[] = []
): (Pos & { capture?: string; via?: string })[] {
  const matchingRules = ruleSet.moves.filter(r => r.pieceType === occ.type || r.pieceType === "*" || r.pieceType === occ.data?.group || occ.type.startsWith(r.pieceType));
  if (matchingRules.length === 0) return [];

  const occMap = buildOccupancyMap(occupants.filter(o => o.id !== occ.id)); // exclude self for collision check but keep self cells? For move we check new cells against others
  const res: (Pos & { capture?: string; via?: string })[] = [];
  const seen = new Set<string>();

  const allowedDirsFromLogic = (() => {
    const triplesForPiece = logicTriples.filter(t => t.s === occ.type && t.p === "canMove");
    if (triplesForPiece.length === 0) return null;
    return new Set(triplesForPiece.map(t => t.o));
  })();

  const pushIf = (p: Pos, cap?: string, via?: string) => {
    const key = `${p.q},${p.r}`;
    if (seen.has(key)) return;
    seen.add(key);
    res.push({ ...p, capture: cap, via });
  };

  for (const rule of matchingRules) {
    // each moveKind
    for (const mk of rule.moves) {
      if (mk.type === "place") {
        // all empty cells
        for (let r = 0; r < height; r++) for (let q = 0; q < width; q++) {
          const pos = { q, r };
          // check collision with span? For place, anchor must be empty and span empty
          const cellsToOccupy = [pos, ...occ.span.map(s => ({ q: pos.q + s.q, r: pos.r + s.r }))];
          const collides = cellsToOccupy.some(c => {
            if (c.q < 0 || c.q >= width || c.r < 0 || c.r >= height) return true;
            const existing = occMap.get(`${c.q},${c.r}`);
            return !!existing;
          });
          if (!collides) pushIf(pos);
        }
        continue;
      }

      if (mk.type === "step") {
        if (allowedDirsFromLogic && !allowedDirsFromLogic.has(mk.dir)) continue;
        if (!tiling.directionMap[mk.dir]) continue;
        if (rule.requires?.darkOnly && (occ.anchor.q + occ.anchor.r) % 2 === 0) continue;
        const count = mk.count ?? 1;
        const target = addPosByDir(occ.anchor, mk.dir, count, tiling, width, height, toggles.wrapping);
        if (!target) continue;
        if (rule.requires?.darkOnly && (target.q + target.r) % 2 === 0) continue;
        // span collision at target
        const targetCells = [target, ...occ.span.map(s => ({ q: target.q + s.q, r: target.r + s.r }))];
        let blockedByOwn = false;
        let captureId: string | undefined;
        for (const c of targetCells) {
          if (c.q < 0 || c.q >= width || c.r < 0 || c.r >= height) { blockedByOwn = true; break; }
          const at = occMap.get(`${c.q},${c.r}`);
          if (at) {
            if (at.data?.player === occ.data?.player) { blockedByOwn = true; break; }
            else captureId = at.id;
          }
        }
        if (blockedByOwn) continue;
        if (captureId) {
          if (rule.capture === "move") continue;
          pushIf(target, captureId, mk.dir);
        } else {
          if (rule.capture === "captureOnly") continue;
          pushIf(target, undefined, mk.dir);
        }
      } else if (mk.type === "slide") {
        if (allowedDirsFromLogic && !allowedDirsFromLogic.has(mk.dir)) continue;
        if (!tiling.directionMap[mk.dir]) continue;
        const min = mk.min ?? 1;
        const max = mk.max ?? Math.max(width, height);
        const effectiveMax = toggles.sliding ? Math.max(max, Math.max(width, height)) : max;
        for (let s = min; s <= effectiveMax; s++) {
          const target = addPosByDir(occ.anchor, mk.dir, s, tiling, width, height, toggles.wrapping);
          if (!target) break;
          if (rule.requires?.darkOnly && (target.q + target.r) % 2 === 0) continue;
          const targetCells = [target, ...occ.span.map(sp => ({ q: target.q + sp.q, r: target.r + sp.r }))];
          let blocked = false;
          let captureId: string | undefined;
          for (const c of targetCells) {
            if (c.q < 0 || c.q >= width || c.r < 0 || c.r >= height) { blocked = true; break; }
            const at = occMap.get(`${c.q},${c.r}`);
            if (at) {
              if (at.data?.player === occ.data?.player) { blocked = true; break; }
              else captureId = at.id;
            }
          }
          if (blocked) {
            // if capture and both, we already captured? Actually for slide, if own blocks stop
            break;
          }
          if (captureId) {
            if (rule.capture !== "move") pushIf(target, captureId, mk.dir);
            break; // stop after capture
          } else {
            if (rule.capture !== "captureOnly") pushIf(target, undefined, mk.dir);
          }
        }
      } else if (mk.type === "leap") {
        for (const off of mk.offsets) {
          const target = applyOffset(occ.anchor, off, tiling, width, height, toggles.wrapping);
          if (!target) continue;
          if (rule.requires?.darkOnly && (target.q + target.r) % 2 === 0) continue;
          const targetCells = [target, ...occ.span.map(sp => ({ q: target.q + sp.q, r: target.r + sp.r }))];
          let blockedByOwn = false;
          let captureId: string | undefined;
          for (const c of targetCells) {
            const at = occMap.get(`${c.q},${c.r}`);
            if (at && at.data?.player === occ.data?.player) { blockedByOwn = true; break; }
            if (at && at.data?.player !== occ.data?.player) captureId = at.id;
          }
          if (blockedByOwn) continue;
          if (captureId) {
            if (rule.capture === "move") continue;
            pushIf(target, captureId, "leap");
          } else {
            if (rule.capture === "captureOnly") continue;
            pushIf(target, undefined, "leap");
          }
        }
      } else if (mk.type === "pawn") {
        const forwards = Array.isArray(mk.forward) ? mk.forward : [mk.forward];
        for (const f of forwards) {
          if (allowedDirsFromLogic && !allowedDirsFromLogic.has(f)) continue;
          if (!tiling.directionMap[f]) continue;
          const one = addPosByDir(occ.anchor, f, 1, tiling, width, height, toggles.wrapping);
          if (!one) continue;
          const oneCells = [one, ...occ.span.map(sp => ({ q: one.q + sp.q, r: one.r + sp.r }))];
          const blocked = oneCells.some(c => occMap.has(`${c.q},${c.r}`));
          if (!blocked && rule.capture !== "captureOnly") pushIf(one, undefined, f);
          if (mk.firstDouble && !occ.data?.hasMoved) {
            const two = addPosByDir(occ.anchor, f, 2, tiling, width, height, toggles.wrapping);
            if (two) {
              const midBlocked = oneCells.some(c => occMap.has(`${c.q},${c.r}`));
              const twoCells = [two, ...occ.span.map(sp => ({ q: two.q + sp.q, r: two.r + sp.r }))];
              const twoBlocked = twoCells.some(c => occMap.has(`${c.q},${c.r}`));
              if (!midBlocked && !twoBlocked && rule.capture !== "captureOnly") pushIf(two, undefined, f);
            }
          }
        }
        for (const capDir of mk.captureDirs) {
          if (allowedDirsFromLogic && !allowedDirsFromLogic.has(capDir)) continue;
          if (!tiling.directionMap[capDir]) continue;
          const target = addPosByDir(occ.anchor, capDir, 1, tiling, width, height, toggles.wrapping);
          if (!target) continue;
          const at = occMap.get(`${target.q},${target.r}`);
          if (at && at.data?.player !== occ.data?.player) {
            if (rule.capture !== "move") pushIf(target, at.id, capDir);
          }
        }
      }
    }
  }
  return res;
}

// ---------- Outcome evaluator (data-driven) ----------
function evaluateOutcomes(
  occupants: Occupant[],
  tiling: TilingDef,
  ruleSet: RuleSet,
  currentPlayer: string,
  width: number,
  height: number,
  getValidMovesFn: (occ: Occupant, occs: Occupant[]) => (Pos & { capture?: string })[]
): string | null {
  // helper maps
  const occByCell = buildOccupancyMap(occupants);

  for (const cond of ruleSet.outcomes) {
    if (cond.kind === "line") {
      const count = cond.count;
      const dirs = cond.directions === "any" ? tiling.directions.map(d => d.name) : (cond.directions as string[]) || tiling.directions.map(d => d.name);
      // for each cell that has occupant
      for (const occ of occupants) {
        const player = occ.data?.player || occ.type;
        if (cond.player !== "any" && cond.player !== player && cond.player !== occ.type) continue;
        for (const dir of dirs) {
          if (!tiling.directionMap[dir]) continue;
          const cells = lineCells(occ.anchor, dir, count, tiling, width, height);
          if (cells.length < count) continue;
          // check all cells occupied by same player
          let allSame = true;
          for (const c of cells) {
            const at = occByCell.get(`${c.q},${c.r}`);
            if (!at) { allSame = false; break; }
            const p = at.data?.player || at.type;
            if (p !== player) { allSame = false; break; }
          }
          if (allSame) {
            return `${player.toUpperCase()} wins • line ${count} ${dir} from ${occ.anchor.q},${occ.anchor.r}`;
          }
        }
      }
    } else if (cond.kind === "captureAll") {
      const opponentPlayers = cond.player === "opponent" ? [currentPlayer === "white" ? "black" : currentPlayer === "black" ? "white" : currentPlayer === "X" ? "O" : currentPlayer === "O" ? "X" : "opponent"] : [cond.player || "opponent"];
      // actually check if no opponent pieces
      const playersInGame = [...new Set(occupants.map(o => o.data?.player).filter(Boolean))];
      // if only one player left
      if (playersInGame.length === 1 && occupants.length > 0) {
        const winner = playersInGame[0];
        // ensure opponent gone
        return `${winner.toUpperCase()} wins • capture all`;
      }
      // also check explicit player param
      if (cond.player && cond.player !== "any") {
        const remaining = occupants.filter(o => o.data?.player === cond.player);
        if (remaining.length === 0) {
          // opponent of that player wins
          const other = occupants[0]?.data?.player || "current";
          return `${other.toUpperCase()} wins • ${cond.player} no pieces`;
        }
      }
    } else if (cond.kind === "kingCaptured") {
      const targetPlayer = cond.player;
      // if target player's king missing
      const kingExists = occupants.some(o => (o.type === "king" || o.type.includes("king")) && o.data?.player === targetPlayer);
      if (!kingExists) {
        const winner = targetPlayer === "white" ? "black" : targetPlayer === "black" ? "white" : "opponent";
        return `${winner.toUpperCase()} wins • ${targetPlayer} king captured`;
      }
      // also generic: if any king missing
      const whiteKing = occupants.some(o => (o.type === "king" || o.type === "king_w") && o.data?.player === "white");
      const blackKing = occupants.some(o => (o.type === "king" || o.type === "king_b") && o.data?.player === "black");
      if (!whiteKing) return "BLACK wins • white king captured";
      if (!blackKing) return "WHITE wins • black king captured";
    } else if (cond.kind === "noMoves") {
      const target = cond.player === "opponent" ? (currentPlayer === "white" ? "black" : currentPlayer === "black" ? "white" : currentPlayer === "X" ? "O" : "X") : cond.player;
      const targetOccs = occupants.filter(o => o.data?.player === target || (target === "any" && true));
      const hasMove = targetOccs.some(o => getValidMovesFn(o, occupants).length > 0);
      if (!hasMove && targetOccs.length > 0) {
        return `${currentPlayer.toUpperCase()} wins • ${target} no moves`;
      }
    } else if (cond.kind === "reachRow") {
      const region = ruleSet.regions.find(r => r.id === cond.regionId);
      if (!region) continue;
      const found = occupants.find(o => o.data?.player === cond.player && isPosInRegion(o.anchor, region));
      if (found) return `${cond.player.toUpperCase()} wins • reach ${cond.regionId}`;
    } else if (cond.kind === "boardFull") {
      // check if board full (consider span)
      let filled = 0;
      for (let r = 0; r < height; r++) for (let q = 0; q < width; q++) if (occByCell.has(`${q},${r}`)) filled++;
      if (filled >= width * height) return "Draw • board full";
    } else if (cond.kind === "fillRegions") {
      // for sudoku: if all cells filled and regions valid
      let filled = 0;
      for (let r = 0; r < height; r++) for (let q = 0; q < width; q++) if (occByCell.has(`${q},${r}`)) filled++;
      if (filled >= width * height) {
        if (cond.constraint === "sudokuValid") {
          // validate sudoku
          let valid = true;
          for (const reg of ruleSet.regions) {
            const nums = reg.cells.map(c => {
              const at = occByCell.get(`${c.q},${c.r}`);
              return at?.data?.value;
            }).filter(Boolean);
            const set = new Set(nums);
            if (set.size !== 9 || nums.length !== 9) { valid = false; break; }
          }
          if (valid) return "Sudoku solved • all regions valid";
        } else {
          return "Draw • board full";
        }
      }
    } else if (cond.kind === "topReached") {
      const atTop = occupants.some(o => o.anchor.r <= cond.row);
      if (atTop) return "Game over • top reached";
    }
  }
  return null;
}

// ---------- Presets (15) ----------
function presetData(presetId: string): { ruleSet: RuleSet; occupants: Occupant[]; width: number; height: number; regions: Region[] } {
  const edge = (w: number, h: number) => makeEdgeRegions(w, h);
  const mkOcc = (q: number, r: number, type: string, player?: string, symbol?: string, span: Pos[] = [], guest?: Guest): Occupant => ({
    id: makeId(), anchor: { q, r }, span, type, data: { player, symbol, hasMoved: false }, tags: [], guest
  });

  switch (presetId) {
    case "tictactoe": {
      const w = 3, h = 3;
      return {
        width: w, height: h, regions: [],
        occupants: [],
        ruleSet: {
          id: "tictactoe",
          setup: { width: w, height: h, description: "Placement, line 3 wins, works on any tiling via line()" },
          moves: [{ pieceType: "*", moves: [{ type: "place", anywhere: true }], capture: "move" }],
          turns: { type: "alternating", order: ["X", "O"], first: "X" },
          outcomes: [
            { kind: "line", player: "any", count: 3, directions: "any", regions: "all" },
            { kind: "boardFull", draw: true }
          ],
          end: { condition: "anyOutcome", action: "stop" },
          regions: []
        }
      };
    }
    case "checkers": {
      const w = 8, h = 8;
      const regions = [...edge(w, h), { id: "promotion-white", cells: Array.from({ length: w }, (_, q) => ({ q, r: 0 })), type: "edge" as const }, { id: "promotion-black", cells: Array.from({ length: w }, (_, q) => ({ q, r: h - 1 })), type: "edge" as const }];
      const occs: Occupant[] = [];
      for (let r = 0; r < 3; r++) for (let q = 0; q < w; q++) if ((q + r) % 2 === 1) occs.push(mkOcc(q, r, "man_b", "black", "●"));
      for (let r = 5; r < h; r++) for (let q = 0; q < w; q++) if ((q + r) % 2 === 1) occs.push(mkOcc(q, r, "man_w", "white", "○"));
      return {
        width: w, height: h, regions,
        occupants: occs,
        ruleSet: {
          id: "checkers",
          setup: { width: w, height: h, description: "Dark only, leap capture, chain, promotion via region" },
          moves: [
            { pieceType: "man_w", moves: [{ type: "step", dir: "NE" }, { type: "step", dir: "NW" }, { type: "leap", offsets: [{ dq: 2, dr: -2, axial: { q: 2, r: -2 } }, { dq: -2, dr: -2, axial: { q: -2, r: 0 } }] }], capture: "both", jumpOver: true, requires: { darkOnly: true }, onCapture: { chain: true }, onMove: { promoteTo: ["king_w"], ifInRegion: "promotion-white" } },
            { pieceType: "man_b", moves: [{ type: "step", dir: "SE" }, { type: "step", dir: "SW" }, { type: "leap", offsets: [{ dq: 2, dr: 2, axial: { q: 0, r: 2 } }, { dq: -2, dr: 2, axial: { q: -2, r: 2 } }] }], capture: "both", jumpOver: true, requires: { darkOnly: true }, onCapture: { chain: true }, onMove: { promoteTo: ["king_b"], ifInRegion: "promotion-black" } },
            { pieceType: "king_w", moves: [{ type: "step", dir: "NE" }, { type: "step", dir: "NW" }, { type: "step", dir: "SE" }, { type: "step", dir: "SW" }, { type: "slide", dir: "NE", min: 1, max: 2 }, { type: "slide", dir: "NW", min: 1, max: 2 }, { type: "slide", dir: "SE", min: 1, max: 2 }, { type: "slide", dir: "SW", min: 1, max: 2 }, { type: "leap", offsets: [{ dq: 2, dr: -2, axial: { q: 2, r: -2 } }, { dq: -2, dr: -2, axial: { q: -2, r: 0 } }, { dq: 2, dr: 2, axial: { q: 0, r: 2 } }, { dq: -2, dr: 2, axial: { q: -2, r: 2 } }] }], capture: "both", jumpOver: true, requires: { darkOnly: true }, onCapture: { chain: true } },
            { pieceType: "king_b", moves: [{ type: "step", dir: "NE" }, { type: "step", dir: "NW" }, { type: "step", dir: "SE" }, { type: "step", dir: "SW" }, { type: "slide", dir: "NE", min: 1, max: 2 }, { type: "slide", dir: "NW", min: 1, max: 2 }, { type: "slide", dir: "SE", min: 1, max: 2 }, { type: "slide", dir: "SW", min: 1, max: 2 }, { type: "leap", offsets: [{ dq: 2, dr: -2, axial: { q: 2, r: -2 } }, { dq: -2, dr: -2, axial: { q: -2, r: 0 } }, { dq: 2, dr: 2, axial: { q: 0, r: 2 } }, { dq: -2, dr: 2, axial: { q: -2, r: 2 } }] }], capture: "both", jumpOver: true, requires: { darkOnly: true }, onCapture: { chain: true } },
          ],
          turns: { type: "samePlayerIfCapture", order: ["white", "black"], first: "white" },
          outcomes: [
            { kind: "captureAll", player: "black" },
            { kind: "captureAll", player: "white" },
            { kind: "noMoves", player: "opponent" }
          ],
          end: { condition: "anyOutcome", action: "stop" },
          regions
        }
      };
    }
    case "chess6": {
      const w = 6, h = 6;
      const regions = [...edge(w, h), { id: "promotion-white", cells: Array.from({ length: w }, (_, q) => ({ q, r: 0 })), type: "edge" as const }, { id: "promotion-black", cells: Array.from({ length: w }, (_, q) => ({ q, r: h - 1 })), type: "edge" as const }];
      const occs: Occupant[] = [];
      const backB = ["rook", "knight", "bishop", "queen", "king", "bishop"];
      const backW = ["rook", "knight", "bishop", "king", "queen", "bishop"];
      backB.forEach((t, i) => occs.push(mkOcc(i, 0, t, "black", t[0].toUpperCase())));
      for (let i = 0; i < 6; i++) occs.push(mkOcc(i, 1, "pawn_b", "black", "♟"));
      for (let i = 0; i < 6; i++) occs.push(mkOcc(i, 4, "pawn_w", "white", "♙"));
      backW.forEach((t, i) => occs.push(mkOcc(i, 5, t, "white", t === "king" ? "♔" : t === "queen" ? "♕" : t[0].toUpperCase())));
      return {
        width: w, height: h, regions,
        occupants: occs,
        ruleSet: {
          id: "chess6",
          setup: { width: w, height: h, description: "Mini chess, knight uses leap offsets (not direction names), promotion via region" },
          moves: [
            { pieceType: "pawn_w", moves: [{ type: "pawn", forward: "N", captureDirs: ["NE", "NW"], firstDouble: true }], capture: "both", onMove: { promoteTo: ["queen", "rook"], ifInRegion: "promotion-white" } },
            { pieceType: "pawn_b", moves: [{ type: "pawn", forward: "S", captureDirs: ["SE", "SW"], firstDouble: true }], capture: "both", onMove: { promoteTo: ["queen", "rook"], ifInRegion: "promotion-black" } },
            { pieceType: "rook", moves: [{ type: "slide", dir: "N" }, { type: "slide", dir: "S" }, { type: "slide", dir: "E" }, { type: "slide", dir: "W" }], capture: "both" },
            { pieceType: "bishop", moves: [{ type: "slide", dir: "NE" }, { type: "slide", dir: "NW" }, { type: "slide", dir: "SE" }, { type: "slide", dir: "SW" }], capture: "both" },
            { pieceType: "queen", moves: [{ type: "slide", dir: "N" }, { type: "slide", dir: "S" }, { type: "slide", dir: "E" }, { type: "slide", dir: "W" }, { type: "slide", dir: "NE" }, { type: "slide", dir: "NW" }, { type: "slide", dir: "SE" }, { type: "slide", dir: "SW" }], capture: "both" },
            { pieceType: "king", moves: [{ type: "step", dir: "N" }, { type: "step", dir: "S" }, { type: "step", dir: "E" }, { type: "step", dir: "W" }, { type: "step", dir: "NE" }, { type: "step", dir: "NW" }, { type: "step", dir: "SE" }, { type: "step", dir: "SW" }], capture: "both" },
            { pieceType: "knight", moves: [{ type: "leap", offsets: TILINGS.square8.leaps.offsets }], capture: "both" },
          ],
          turns: { type: "alternating", order: ["white", "black"], first: "white" },
          outcomes: [
            { kind: "kingCaptured", player: "white" },
            { kind: "kingCaptured", player: "black" },
            { kind: "noMoves", player: "opponent" }
          ],
          end: { condition: "anyOutcome", action: "stop" },
          regions
        }
      };
    }
    case "chess8": {
      const base = presetData("chess6");
      const w = 8, h = 8;
      const regions = [...edge(w, h), { id: "promotion-white", cells: Array.from({ length: w }, (_, q) => ({ q, r: 0 })), type: "edge" as const }, { id: "promotion-black", cells: Array.from({ length: w }, (_, q) => ({ q, r: h - 1 })), type: "edge" as const }];
      const occs: Occupant[] = [];
      const back = ["rook", "knight", "bishop", "queen", "king", "bishop", "knight", "rook"];
      back.forEach((t, i) => occs.push(mkOcc(i, 0, t, "black", t[0].toUpperCase())));
      for (let i = 0; i < 8; i++) occs.push(mkOcc(i, 1, "pawn_b", "black", "♟"));
      for (let i = 0; i < 8; i++) occs.push(mkOcc(i, 6, "pawn_w", "white", "♙"));
      back.forEach((t, i) => occs.push(mkOcc(i, 7, t, "white", t === "king" ? "♔" : t === "queen" ? "♕" : t[0].toUpperCase())));
      return {
        width: w, height: h, regions,
        occupants: occs,
        ruleSet: {
          ...base.ruleSet,
          id: "chess8",
          setup: { width: w, height: h, description: "Full 8x8, same engine, leap knight works on any tiling" },
          regions
        }
      };
    }
    case "hexChess": {
      const w = 6, h = 6;
      const regions = [...edge(w, h), { id: "promotion-white", cells: Array.from({ length: w }, (_, q) => ({ q, r: 0 })), type: "edge" as const }, { id: "promotion-black", cells: Array.from({ length: w }, (_, q) => ({ q, r: h - 1 })), type: "edge" as const }];
      const occs: Occupant[] = [];
      const backB = ["rook", "knight", "bishop", "queen", "king", "bishop"];
      const backW = ["rook", "knight", "bishop", "king", "queen", "bishop"];
      backB.forEach((t, i) => occs.push(mkOcc(i, 0, t, "black", t[0].toUpperCase())));
      for (let i = 0; i < 6; i++) occs.push(mkOcc(i, 1, "pawn_b", "black", "♟"));
      for (let i = 0; i < 6; i++) occs.push(mkOcc(i, 4, "pawn_w", "white", "♙"));
      backW.forEach((t, i) => occs.push(mkOcc(i, 5, t, "white", t[0].toUpperCase())));
      return {
        width: w, height: h, regions,
        occupants: occs,
        ruleSet: {
          id: "hexChess",
          setup: { width: w, height: h, description: "Hex chess on hexH — uses hex directions E,W,NE,NW,SE,SW (no N/S reuse)" },
          moves: [
            { pieceType: "pawn_w", moves: [{ type: "step", dir: "NE" }, { type: "step", dir: "NW" }, { type: "step", dir: "E", }, { type: "step", dir: "W" }], capture: "both", onMove: { promoteTo: ["queen"], ifInRegion: "promotion-white" } },
            { pieceType: "pawn_b", moves: [{ type: "step", dir: "SE" }, { type: "step", dir: "SW" }, { type: "step", dir: "E" }, { type: "step", dir: "W" }], capture: "both", onMove: { promoteTo: ["queen"], ifInRegion: "promotion-black" } },
            { pieceType: "rook", moves: [{ type: "slide", dir: "E" }, { type: "slide", dir: "W" }, { type: "slide", dir: "NE" }, { type: "slide", dir: "NW" }, { type: "slide", dir: "SE" }, { type: "slide", dir: "SW" }], capture: "both" },
            { pieceType: "bishop", moves: [{ type: "slide", dir: "NE" }, { type: "slide", dir: "NW" }, { type: "slide", dir: "SE" }, { type: "slide", dir: "SW" }], capture: "both" },
            { pieceType: "queen", moves: [{ type: "slide", dir: "E" }, { type: "slide", dir: "W" }, { type: "slide", dir: "NE" }, { type: "slide", dir: "NW" }, { type: "slide", dir: "SE" }, { type: "slide", dir: "SW" }], capture: "both" },
            { pieceType: "king", moves: [{ type: "step", dir: "E" }, { type: "step", dir: "W" }, { type: "step", dir: "NE" }, { type: "step", dir: "NW" }, { type: "step", dir: "SE" }, { type: "step", dir: "SW" }], capture: "both" },
            { pieceType: "knight", moves: [{ type: "leap", offsets: TILINGS.hexH.leaps.offsets }], capture: "both" },
          ],
          turns: { type: "alternating", order: ["white", "black"], first: "white" },
          outcomes: [
            { kind: "kingCaptured", player: "white" },
            { kind: "kingCaptured", player: "black" },
          ],
          end: { condition: "anyOutcome", action: "stop" },
          regions
        }
      };
    }
    case "painter": {
      const w = 12, h = 12;
      return {
        width: w, height: h, regions: [],
        occupants: [],
        ruleSet: {
          id: "painter",
          setup: { width: w, height: h, description: "Toggle paint, span 1, uses tiling style 3color" },
          moves: [{ pieceType: "*", moves: [{ type: "place", anywhere: true }], capture: "move" }],
          turns: { type: "free", order: [], first: "painter" } as any,
          outcomes: [],
          end: { condition: "manual", action: "none" },
          regions: []
        }
      };
    }
    case "sequencer": {
      const w = 16, h = 4;
      const occs: Occupant[] = [
        { id: makeId(), anchor: { q: 2, r: 0 }, span: [{ q: 1, r: 0 }, { q: 2, r: 0 }], type: "note", data: { player: "composer", vel: 0.8 }, tags: [], guest: { kind: "Path", state: { points: [{ x: 0, y: 10 }, { x: 20, y: 0 }, { x: 40, y: 10 }] } } },
        { id: makeId(), anchor: { q: 6, r: 1 }, span: [{ q: 1, r: 0 }], type: "note", data: { player: "composer" }, tags: [], guest: { kind: "Path", state: { points: [{ x: 0, y: 5 }, { x: 30, y: 15 }] } } },
        { id: makeId(), anchor: { q: 10, r: 2 }, span: [{ q: 1, r: 0 }, { q: 2, r: 0 }, { q: 3, r: 0 }], type: "clip", data: { player: "composer" }, tags: [], guest: { kind: "Grid", state: { occupants: [], width: 3, height: 1 } } },
      ];
      return {
        width: w, height: h,
        regions: makeTrackRegions(w, h),
        occupants: occs,
        ruleSet: {
          id: "sequencer",
          setup: { width: w, height: h, description: "Grid=timeline steps×tracks, occupant span=duration, guest=Path automation" },
          moves: [
            { pieceType: "note", moves: [{ type: "slide", dir: "E", min: 1, max: 1 }, { type: "slide", dir: "W", min: 1, max: 1 }], capture: "move" },
            { pieceType: "clip", moves: [{ type: "slide", dir: "E" }, { type: "slide", dir: "W" }], capture: "move" },
            { pieceType: "*", moves: [{ type: "place", anywhere: true }], capture: "move" }
          ],
          turns: { type: "free", order: [], first: "composer" } as any,
          outcomes: [],
          end: { condition: "none", action: "none" },
          regions: makeTrackRegions(w, h)
        }
      };
    }
    case "tetris": {
      const w = 10, h = 16;
      const shapes: Record<string, Pos[]> = {
        O: [{ q: 0, r: 0 }, { q: 1, r: 0 }, { q: 0, r: 1 }, { q: 1, r: 1 }],
        I: [{ q: -1, r: 0 }, { q: 0, r: 0 }, { q: 1, r: 0 }, { q: 2, r: 0 }],
        T: [{ q: -1, r: 0 }, { q: 0, r: 0 }, { q: 1, r: 0 }, { q: 0, r: 1 }],
        L: [{ q: -1, r: 0 }, { q: 0, r: 0 }, { q: 1, r: 0 }, { q: 1, r: 1 }],
      };
      const occs: Occupant[] = [
        { id: makeId(), anchor: { q: 4, r: 2 }, span: shapes.T.slice(1), type: "tetromino", data: { player: "player", shape: "T" }, tags: ["falling"] },
        { id: makeId(), anchor: { q: 2, r: 12 }, span: shapes.O.slice(1), type: "locked", data: { player: "board" }, tags: [] },
        { id: makeId(), anchor: { q: 6, r: 13 }, span: shapes.I.slice(1), type: "locked", data: { player: "board" }, tags: [] },
      ];
      return {
        width: w, height: h, regions: edge(w, h),
        occupants: occs,
        ruleSet: {
          id: "tetris",
          setup: { width: w, height: h, description: "Multi-cell tetrominoes span, rotation via tiling.rotateSpan, gravity turn effect" },
          moves: [
            { pieceType: "tetromino", moves: [{ type: "step", dir: "E" }, { type: "step", dir: "W" }, { type: "step", dir: "S" }, { type: "leap", offsets: [{ dq: 0, dr: -1, axial: { q: 0, r: -1 } }] }], capture: "move" }
          ],
          turns: { type: "alternating", order: ["player", "gravity"], first: "player" },
          outcomes: [{ kind: "topReached", row: 0 }],
          end: { condition: "anyOutcome", action: "stop" },
          regions: edge(w, h),
          gravity: { direction: "S", after: "move" }
        }
      };
    }
    case "timeline": {
      const w = 20, h = 4;
      const occs: Occupant[] = [
        { id: makeId(), anchor: { q: 1, r: 0 }, span: [{ q: 1, r: 0 }, { q: 2, r: 0 }, { q: 3, r: 0 }], type: "clip", data: { player: "editor", label: "A-cam" }, tags: [], guest: { kind: "Path", state: { points: [{ x: 0, y: 10 }, { x: 30, y: 0 }] } }, z: 1 },
        { id: makeId(), anchor: { q: 6, r: 0 }, span: [{ q: 1, r: 0 }, { q: 2, r: 0 }], type: "clip", data: { player: "editor", label: "B-cam" }, tags: [], guest: { kind: "Path", state: { points: [{ x: 0, y: 5 }, { x: 20, y: 15 }] } }, z: 2 },
        { id: makeId(), anchor: { q: 4, r: 0 }, span: [{ q: 1, r: 0 }], type: "transition", data: { player: "editor", label: "x-fade" }, tags: ["overlap"], z: 3 },
      ];
      return {
        width: w, height: h, regions: makeTrackRegions(w, h),
        occupants: occs,
        ruleSet: {
          id: "timeline",
          setup: { width: w, height: h, description: "NLE: Grid time×tracks, clips span=duration, guest=Path, stacking/overlap for transitions" },
          moves: [
            { pieceType: "clip", moves: [{ type: "slide", dir: "E" }, { type: "slide", dir: "W" }], capture: "move" },
            { pieceType: "transition", moves: [{ type: "slide", dir: "E" }, { type: "slide", dir: "W" }], capture: "move" },
            { pieceType: "*", moves: [{ type: "place" }], capture: "move" }
          ],
          turns: { type: "free", order: [], first: "editor" } as any,
          outcomes: [],
          end: { condition: "none", action: "none" },
          regions: makeTrackRegions(w, h)
        }
      };
    }
    case "crossword": {
      const w = 8, h = 8;
      const blocked: Pos[] = [{ q: 2, r: 2 }, { q: 5, r: 2 }, { q: 2, r: 5 }, { q: 5, r: 5 }];
      const occs: Occupant[] = blocked.map(p => ({ id: makeId(), anchor: p, span: [], type: "block", data: { player: "board", symbol: "█" }, tags: [] }));
      occs.push({ id: makeId(), anchor: { q: 0, r: 0 }, span: [], type: "letter", data: { player: "solver", symbol: "C" }, tags: [] });
      occs.push({ id: makeId(), anchor: { q: 1, r: 0 }, span: [], type: "letter", data: { player: "solver", symbol: "A" }, tags: [] });
      occs.push({ id: makeId(), anchor: { q: 3, r: 0 }, span: [], type: "letter", data: { player: "solver", symbol: "T" }, tags: [] });
      // regions = words (horizontal sequences without block)
      const regions: Region[] = [];
      // simple: rows split by blocks
      for (let r = 0; r < h; r++) {
        let start = 0;
        for (let q = 0; q <= w; q++) {
          const isBlock = q === w || blocked.some(b => b.q === q && b.r === r);
          if (isBlock) {
            if (q - start >= 2) regions.push({ id: `word-h-${r}-${start}`, cells: Array.from({ length: q - start }, (_, i) => ({ q: start + i, r })), type: "word" });
            start = q + 1;
          }
        }
      }
      for (let q = 0; q < w; q++) {
        let start = 0;
        for (let r = 0; r <= h; r++) {
          const isBlock = r === h || blocked.some(b => b.q === q && b.r === r);
          if (isBlock) {
            if (r - start >= 2) regions.push({ id: `word-v-${q}-${start}`, cells: Array.from({ length: r - start }, (_, i) => ({ q, r: start + i })), type: "word" });
            start = r + 1;
          }
        }
      }
      return {
        width: w, height: h, regions,
        occupants: occs,
        ruleSet: {
          id: "crossword",
          setup: { width: w, height: h, description: "Blocked cells as occupants type block, letters as occupants, regions=words" },
          moves: [{ pieceType: "letter", moves: [{ type: "place" }], capture: "move" }],
          turns: { type: "free", order: [], first: "solver" } as any,
          outcomes: [],
          end: { condition: "none", action: "none" },
          regions
        }
      };
    }
    case "connectFour": {
      const w = 7, h = 6;
      return {
        width: w, height: h, regions: [],
        occupants: [],
        ruleSet: {
          id: "connectFour",
          setup: { width: w, height: h, description: "Gravity S, line 4 wins — uses executable line outcome" },
          moves: [{ pieceType: "*", moves: [{ type: "place", anywhere: true }], capture: "move" }],
          turns: { type: "alternating", order: ["R", "Y"], first: "R" },
          outcomes: [
            { kind: "line", player: "any", count: 4, directions: "any", regions: "all" },
            { kind: "boardFull", draw: true }
          ],
          end: { condition: "anyOutcome", action: "stop" },
          regions: [],
          gravity: { direction: "S", after: "always" }
        }
      };
    }
    case "go": {
      const w = 9, h = 9;
      const occs: Occupant[] = [
        mkOcc(2, 2, "stone", "black", "●"),
        mkOcc(3, 2, "stone", "white", "○"),
        mkOcc(2, 3, "stone", "white", "○"),
      ];
      return {
        width: w, height: h, regions: [],
        occupants: occs,
        ruleSet: {
          id: "go",
          setup: { width: w, height: h, description: "Placement only, capture via surrounding liberties (group capture)" },
          moves: [{ pieceType: "*", moves: [{ type: "place" }], capture: "move" }],
          turns: { type: "alternating", order: ["black", "white"], first: "black" },
          outcomes: [{ kind: "captureAll", player: "white" }, { kind: "captureAll", player: "black" }],
          end: { condition: "anyOutcome", action: "stop" },
          regions: []
        }
      };
    }
    case "breakout": {
      const w = 10, h = 12;
      const occs: Occupant[] = [];
      for (let r = 0; r < 3; r++) for (let q = 0; q < w; q++) occs.push(mkOcc(q, r, "brick", "board", "■"));
      occs.push(mkOcc(5, 10, "paddle", "player", "═", [{ q: 1, r: 0 }, { q: -1, r: 0 }]));
      occs.push(mkOcc(5, 8, "ball", "player", "●"));
      return {
        width: w, height: h, regions: edge(w, h),
        occupants: occs,
        ruleSet: {
          id: "breakout",
          setup: { width: w, height: h, description: "Bricks as occupants, ball slide diagonal, paddle span 3, captureAll bricks win" },
          moves: [
            { pieceType: "ball", moves: [{ type: "slide", dir: "NE", min: 1, max: 1 }, { type: "slide", dir: "NW", min: 1, max: 1 }, { type: "slide", dir: "SE", min: 1, max: 1 }, { type: "slide", dir: "SW", min: 1, max: 1 }], capture: "both" },
            { pieceType: "paddle", moves: [{ type: "slide", dir: "E" }, { type: "slide", dir: "W" }], capture: "move" },
          ],
          turns: { type: "alternating", order: ["player", "ball"], first: "player" },
          outcomes: [{ kind: "captureAll", player: "board" }],
          end: { condition: "anyOutcome", action: "stop" },
          regions: edge(w, h)
        }
      };
    }
    case "drumPad": {
      const w = 4, h = 4;
      const occs: Occupant[] = [];
      const notes = ["C1", "D1", "E1", "F1", "G1", "A1", "B1", "C2", "D2", "E2", "F2", "G2", "A2", "B2", "C3", "D3"];
      for (let r = 0; r < h; r++) for (let q = 0; q < w; q++) {
        const idx = r * w + q;
        occs.push({
          id: makeId(), anchor: { q, r }, span: [], type: "pad",
          data: { player: "drummer", label: notes[idx] },
          tags: [],
          guest: { kind: "Logic", state: { triples: [{ id: makeId(), s: "pad", p: "triggers", o: notes[idx] }] } }
        });
      }
      return {
        width: w, height: h, regions: [],
        occupants: occs,
        ruleSet: {
          id: "drumPad",
          setup: { width: w, height: h, description: "Single cell pads, guest=Logic triple for MIDI mapping" },
          moves: [{ pieceType: "pad", moves: [{ type: "step", dir: "N" }, { type: "step", dir: "S" }], capture: "move" }],
          turns: { type: "free", order: [], first: "drummer" } as any,
          outcomes: [],
          end: { condition: "none", action: "none" },
          regions: []
        }
      };
    }
    case "sudoku": {
      const w = 9, h = 9;
      const regions = makeSudokuRegions();
      const occs: Occupant[] = [
        mkOcc(0, 0, "num", "given", "5"), mkOcc(1, 0, "num", "given", "3"), mkOcc(4, 0, "num", "given", "7"),
        mkOcc(0, 1, "num", "given", "6"), mkOcc(3, 1, "num", "given", "1"), mkOcc(4, 1, "num", "given", "9"), mkOcc(5, 1, "num", "given", "5"),
        mkOcc(1, 2, "num", "given", "9"), mkOcc(2, 2, "num", "given", "8"),
      ].map(o => ({ ...o, data: { ...o.data, value: o.data.symbol } }));
      return {
        width: w, height: h, regions,
        occupants: occs,
        ruleSet: {
          id: "sudoku",
          setup: { width: w, height: h, description: "Regions for validation, occupants with numbers, fillRegions outcome" },
          moves: [{ pieceType: "*", moves: [{ type: "place" }], capture: "move" }],
          turns: { type: "free", order: [], first: "solver" } as any,
          outcomes: [{ kind: "fillRegions", constraint: "sudokuValid" }],
          end: { condition: "anyOutcome", action: "stop" },
          regions
        }
      };
    }
    default: {
      const w = 6, h = 6;
      return {
        width: w, height: h, regions: edge(w, h),
        occupants: [],
        ruleSet: {
          id: "custom",
          setup: { width: w, height: h, description: "Custom" },
          moves: [{ pieceType: "*", moves: [{ type: "step", dir: "N" }], capture: "move" }],
          turns: { type: "alternating", order: ["white", "black"], first: "white" },
          outcomes: [],
          end: { condition: "none", action: "none" },
          regions: edge(w, h)
        }
      };
    }
  }
}

// ---------- API ----------
async function apiCall(action: string, args: any) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || j.error) throw new Error(j.error || `HTTP ${res.status}`);
  return j.data;
}

// ---------- Components ----------
function DirectionCompass({ tiling }: { tiling: TilingDef }) {
  return (
    <div className="flex flex-wrap gap-1">
      {tiling.directions.map(d => (
        <div key={d.name} className="px-2 py-1 rounded-full bg-[var(--bg-3)] border border-[var(--border)] text-[9px] flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-[var(--accent)]" style={{ transform: `rotate(${d.angle}deg)` }} />
          {d.name}
          <span className="text-[7px] text-[var(--text-faint)]">{d.dq},{d.dr}</span>
        </div>
      ))}
      <div className="px-2 py-1 rounded-full bg-[var(--lime-bg)] border border-[var(--accent)] text-[9px] text-[var(--accent)]">
        {tiling.id} • {tiling.shape} • {tiling.style}
      </div>
    </div>
  );
}

function GridViewport({
  occupants, setOccupants, tiling, ruleSet, width, height, toggles, selectedId, setSelectedId, validMoves, setValidMoves,
  currentTurn, setCurrentTurn, outcome, setOutcome, chainCaptureActive, setChainCaptureActive, logicTriples, showRegions, setShowRegions, showSpan, knightDemo, setKnightDemo
}: any) {
  const cellSize = tiling.shape === "square" ? 44 : 40;

  const mapOccupant = useMemo(() => {
    const m = new Map<string, Occupant>();
    occupants.forEach((o: Occupant) => {
      getOccupiedCells(o).forEach(c => m.set(`${c.q},${c.r}`, o));
    });
    return m;
  }, [occupants]);

  // compute valid moves when selection changes
  useEffect(() => {
    if (!selectedId) { setValidMoves([]); return; }
    const occ = occupants.find((o: Occupant) => o.id === selectedId);
    if (!occ) { setValidMoves([]); return; }
    const moves = getValidMoves(occ, occupants, tiling, ruleSet, width, height, toggles, logicTriples);
    setValidMoves(moves);
  }, [selectedId, occupants, tiling, ruleSet, width, height, toggles, logicTriples]);

  // check outcome generic
  const checkOutcome = (occs: Occupant[], turn: string) => {
    const fn = (o: Occupant, all: Occupant[]) => getValidMoves(o, all, tiling, ruleSet, width, height, toggles, logicTriples);
    return evaluateOutcomes(occs, tiling, ruleSet, turn, width, height, fn);
  };

  const applyGravity = (occs: Occupant[]): Occupant[] => {
    if (!toggles.gravity && !ruleSet.gravity) return occs;
    const dirName = ruleSet.gravity?.direction || "S";
    const dir = tiling.directionMap[dirName];
    if (!dir) return occs;
    // sort by opposite of gravity to avoid collisions
    const sorted = [...occs].sort((a, b) => {
      if (dirName === "S") return b.anchor.r - a.anchor.r;
      if (dirName === "N") return a.anchor.r - b.anchor.r;
      if (dirName === "E") return b.anchor.q - a.anchor.q;
      return a.anchor.q - b.anchor.q;
    });
    const occupiedSet = new Set<string>();
    sorted.forEach(o => getOccupiedCells(o).forEach(c => occupiedSet.add(`${c.q},${c.r}`)));
    const result: Occupant[] = [];
    for (const o of sorted) {
      // remove self from set
      getOccupiedCells(o).forEach(c => occupiedSet.delete(`${c.q},${c.r}`));
      let cur = o.anchor;
      while (true) {
        const nxt = addPosByDir(cur, dirName, 1, tiling, width, height, false);
        if (!nxt) break;
        const cells = [nxt, ...o.span.map(s => ({ q: nxt.q + s.q, r: nxt.r + s.r }))];
        const collides = cells.some(c => c.q < 0 || c.q >= width || c.r < 0 || c.r >= height || occupiedSet.has(`${c.q},${c.r}`));
        if (collides) break;
        cur = nxt;
      }
      const newOcc = { ...o, anchor: cur };
      getOccupiedCells(newOcc).forEach(c => occupiedSet.add(`${c.q},${c.r}`));
      result.push(newOcc);
    }
    return result;
  };

  const handleCellClick = (q: number, r: number) => {
    if (outcome) return;
    const clickedOcc = mapOccupant.get(`${q},${r}`) || null;
    const isValidTarget = validMoves.some((m: any) => m.q === q && m.r === r);

    // painter mode or free placement
    const isPlaceRule = ruleSet.moves.some((mr: MoveRule) => mr.moves.some(mk => mk.type === "place"));
    const isPainter = ruleSet.id === "painter" || ruleSet.turns.type === "free";

    if (isPainter && isPlaceRule && !selectedId) {
      if (clickedOcc) {
        setOccupants((prev: Occupant[]) => prev.filter(o => o.id !== clickedOcc.id));
      } else {
        // check if ConnectFour gravity: find lowest empty
        let target: Pos = { q, r };
        if (ruleSet.gravity?.direction === "S" || toggles.gravity) {
          // find lowest empty in column
          for (let rr = height - 1; rr >= 0; rr--) {
            const test = { q, r: rr };
            if (!mapOccupant.has(`${q},${rr}`)) { target = test; break; }
          }
        }
        const player = currentTurn;
        const sym = player === "R" ? "🔴" : player === "Y" ? "🟡" : player === "X" ? "X" : player === "O" ? "O" : "●";
        const newOcc: Occupant = { id: makeId(), anchor: target, span: [], type: player === "R" || player === "Y" ? "disc" : "mark", data: { player, symbol: sym, hasMoved: true }, tags: [] };
        let newOccs = [...occupants, newOcc];
        if (toggles.gravity || ruleSet.gravity) newOccs = applyGravity(newOccs);
        // Go capture check
        if (ruleSet.id === "go") {
          // simple liberty check for opponent groups
          const groups = findGoGroups(newOccs, tiling, width, height);
          const toRemove: Set<string> = new Set();
          groups.forEach(g => {
            if (g.player !== player) {
              const liberties = countLiberties(g.cells, newOccs, tiling, width, height);
              if (liberties === 0) g.occupants.forEach(id => toRemove.add(id));
            }
          });
          newOccs = newOccs.filter(o => !toRemove.has(o.id));
        }
        setOccupants(newOccs);
        const out = checkOutcome(newOccs, player);
        if (out) setOutcome(out);
        else if (ruleSet.turns.type === "alternating") {
          const order = (ruleSet.turns as any).order;
          const idx = order.indexOf(player);
          const next = order[(idx + 1) % order.length];
          setCurrentTurn(next);
        }
      }
      return;
    }

    if (isValidTarget && selectedId) {
      const sel = occupants.find((o: Occupant) => o.id === selectedId);
      if (!sel) return;
      if (ruleSet.turns.type === "alternating") {
        const order = (ruleSet.turns as any).order;
        if (sel.data?.player && order.includes(sel.data.player) && sel.data.player !== currentTurn) return;
      }

      let newOccs = [...occupants];
      const capMove = validMoves.find((m: any) => m.q === q && m.r === r) as any;
      if (capMove?.capture) newOccs = newOccs.filter(o => o.id !== capMove.capture);
      else if (clickedOcc && clickedOcc.data?.player !== sel.data?.player) newOccs = newOccs.filter(o => o.id !== clickedOcc.id);

      newOccs = newOccs.map(o => o.id === sel.id ? { ...o, anchor: { q, r }, data: { ...o.data, hasMoved: true } } : o);

      // promotion via region
      const matchingRule = ruleSet.moves.find(mr => mr.pieceType === sel.type || mr.pieceType === "*");
      if (matchingRule?.onMove?.ifInRegion) {
        const region = ruleSet.regions.find(rg => rg.id === matchingRule.onMove!.ifInRegion);
        if (region && isPosInRegion({ q, r }, region)) {
          const promoteTo = matchingRule.onMove!.promoteTo?.[0];
          if (promoteTo) newOccs = newOccs.map(o => o.id === sel.id ? { ...o, type: promoteTo, data: { ...o.data, symbol: promoteTo === "queen" ? "♕" : promoteTo === "king_w" ? "♔" : "♚" } } : o);
        }
      }

      if (toggles.gravity || ruleSet.gravity) newOccs = applyGravity(newOccs);

      // chain capture
      const movedSel = newOccs.find(o => o.id === sel.id);
      if (movedSel && capMove?.capture && (toggles.chainCapture || ruleSet.moves.some(m => m.onCapture?.chain))) {
        const further = getValidMoves(movedSel, newOccs, tiling, ruleSet, width, height, toggles, logicTriples).filter((m: any) => m.capture);
        if (further.length > 0) {
          setOccupants(newOccs);
          setSelectedId(sel.id);
          setValidMoves(further);
          setChainCaptureActive(true);
          const out = checkOutcome(newOccs, currentTurn);
          if (out) setOutcome(out);
          return;
        }
      }

      setOccupants(newOccs);
      setChainCaptureActive(false);
      const out = checkOutcome(newOccs, currentTurn);
      if (out) setOutcome(out);
      else {
        if (ruleSet.turns.type === "alternating") {
          const order = (ruleSet.turns as any).order;
          const idx = order.indexOf(currentTurn);
          const next = order[(idx + 1) % order.length] || currentTurn;
          // samePlayerIfCapture handled above
          setCurrentTurn(next);
        } else if (ruleSet.turns.type === "samePlayerIfCapture") {
          if (!capMove?.capture) {
            const order = (ruleSet.turns as any).order;
            const idx = order.indexOf(currentTurn);
            setCurrentTurn(order[(idx + 1) % order.length]);
          }
        }
        setSelectedId(null);
        setValidMoves([]);
      }
    } else if (clickedOcc) {
      if (ruleSet.turns.type === "alternating" && clickedOcc.data?.player && clickedOcc.data?.player !== currentTurn && ruleSet.turns.type !== "free") {
        if (chainCaptureActive) return;
      }
      if (ruleSet.id === "tictactoe" || ruleSet.id === "connectFour" || ruleSet.id === "go" || ruleSet.id === "painter" || ruleSet.id === "sudoku" || ruleSet.id === "crossword") {
        // placement handled earlier when no selection, but for those we already did painter path
        // for tictactoe etc, clicking empty should place, but we have selected logic? Let's handle empty click for place rules when no selection
        // For tictactoe, if clicking occupied does nothing
        if (isPlaceRule && !selectedId) return;
      }
      setSelectedId(clickedOcc.id);
    } else {
      // empty cell, maybe place for place rules
      if (isPlaceRule && !selectedId) {
        let target: Pos = { q, r };
        if (ruleSet.gravity?.direction === "S" || toggles.gravity) {
          for (let rr = height - 1; rr >= 0; rr--) if (!mapOccupant.has(`${q},${rr}`)) { target = { q, r: rr }; break; }
        }
        const player = currentTurn;
        const sym = player === "R" ? "🔴" : player === "Y" ? "🟡" : player === "X" ? "X" : player === "O" ? "O" : "●";
        const newOcc: Occupant = { id: makeId(), anchor: target, span: [], type: player === "R" || player === "Y" ? "disc" : "mark", data: { player, symbol: sym, hasMoved: true }, tags: [] };
        let newOccs = [...occupants, newOcc];
        if (toggles.gravity || ruleSet.gravity) newOccs = applyGravity(newOccs);
        if (ruleSet.id === "go") {
          const groups = findGoGroups(newOccs, tiling, width, height);
          const toRemove: Set<string> = new Set();
          groups.forEach(g => {
            if (g.player !== player) {
              const libs = countLiberties(g.cells, newOccs, tiling, width, height);
              if (libs === 0) g.occupants.forEach(id => toRemove.add(id));
            }
          });
          newOccs = newOccs.filter(o => !toRemove.has(o.id));
        }
        setOccupants(newOccs);
        const out = checkOutcome(newOccs, player);
        if (out) setOutcome(out);
        else if (ruleSet.turns.type === "alternating") {
          const order = (ruleSet.turns as any).order;
          const idx = order.indexOf(player);
          setCurrentTurn(order[(idx + 1) % order.length]);
        }
      } else {
        if (!chainCaptureActive) { setSelectedId(null); setValidMoves([]); }
      }
    }
  };

  // knight demo leaps
  const knightLeaps = useMemo(() => {
    if (!knightDemo || !selectedId) return [];
    const sel = occupants.find((o: Occupant) => o.id === selectedId);
    if (!sel) return [];
    const offs = tiling.leaps.offsets;
    return offs.map(off => applyOffset(sel.anchor, off, tiling, width, height, false)).filter(Boolean) as Pos[];
  }, [knightDemo, selectedId, occupants, tiling, width, height]);

  const getCellStyle = (q: number, r: number) => {
    const isValid = validMoves.some((m: any) => m.q === q && m.r === r);
    const isSelected = occupants.some(o => o.id === selectedId && getOccupiedCells(o).some(c => c.q === q && c.r === r));
    const isKnightLeap = knightLeaps.some((p: Pos) => p.q === q && p.r === r);
    let bg = "var(--bg-3)";
    if (tiling.style === "2color") bg = (q + r) % 2 === 0 ? "#1a1d21" : "#22262e";
    else {
      const mod = (q + r * 2) % 3;
      bg = mod === 0 ? "#1b1e24" : mod === 1 ? "#20242c" : "#252a33";
    }
    if (isValid) bg = "rgba(232,255,82,0.22)";
    if (isSelected) bg = "rgba(232,255,82,0.32)";
    if (isKnightLeap) bg = "rgba(120,180,255,0.22)";
    const border = isValid ? "1px solid var(--accent)" : isKnightLeap ? "1px dashed #78b4ff" : "1px solid var(--border)";
    return { bg, border, isValid, isSelected, isKnightLeap };
  };

  const containerWidth = tiling.shape === "square" ? width * cellSize : width * cellSize * 0.88 + 30;
  const containerHeight = tiling.shape === "square" ? height * cellSize : height * cellSize * 0.78 + 30;

  const selectedOcc = occupants.find((o: Occupant) => o.id === selectedId);

  return (
    <div className="relative w-full h-full flex flex-col">
      <div className="flex flex-wrap gap-2 mb-2">
        <button onClick={() => setShowRegions(!showRegions)} className={`px-2 py-1 rounded-full text-[10px] border ${showRegions ? "bg-[var(--accent)] text-black border-[var(--accent)]" : "bg-[var(--bg-3)] border-[var(--border)]"}`}>REGIONS {showRegions ? "ON" : "OFF"}</button>
        <button onClick={() => setKnightDemo(!knightDemo)} className={`px-2 py-1 rounded-full text-[10px] border ${knightDemo ? "bg-[#78b4ff] text-black border-[#78b4ff]" : "bg-[var(--bg-3)] border-[var(--border)]"}`}>KNIGHT LEAPS {knightDemo ? "ON" : "OFF"} • offset moves, not dir names</button>
        <span className="text-[10px] text-[var(--text-faint)]">SPAN: {selectedOcc ? `${selectedOcc.span.length + 1} cells • ${selectedOcc.span.length > 0 ? "multi-cell" : "single"}` : "none"} {selectedOcc?.guest ? `• GUEST:${selectedOcc.guest.kind}` : ""}</span>
      </div>

      <div className="relative mx-auto mt-2" style={{ width: containerWidth, height: containerHeight, minHeight: containerHeight }}>
        {Array.from({ length: height }).map((_, r) =>
          Array.from({ length: width }).map((_, q) => {
            const { bg, border, isValid, isSelected, isKnightLeap } = getCellStyle(q, r);
            let left = q * cellSize;
            let top = r * cellSize;
            let clipPath: string | undefined;
            if (tiling.id === "hexH") {
              const size = 26;
              left = q * size * 1.732 + (r % 2 ? size * 0.866 : 0);
              top = r * size * 1.5;
              clipPath = "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)";
            } else if (tiling.id === "hexV") {
              const size = 26;
              left = q * size * 1.5;
              top = r * size * 1.732 + (q % 2 ? size * 0.866 : 0);
              clipPath = "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)";
            }
            const occ = mapOccupant.get(`${q},${r}`);
            const isAnchor = occ && occ.anchor.q === q && occ.anchor.r === r;
            const isInSelectedSpan = selectedOcc && getOccupiedCells(selectedOcc).some(c => c.q === q && c.r === r);
            const regionHere = showRegions ? ruleSet.regions.find((rg: Region) => rg.cells.some(c => c.q === q && c.r === r)) : null;
            return (
              <div
                key={`${q}-${r}`}
                onClick={() => handleCellClick(q, r)}
                className="absolute flex items-center justify-center select-none cursor-pointer transition-all"
                style={{
                  left, top,
                  width: tiling.shape === "square" ? cellSize - 2 : 44,
                  height: tiling.shape === "square" ? cellSize - 2 : 44,
                  background: bg,
                  border,
                  clipPath,
                  borderRadius: tiling.shape === "square" ? 8 : 0,
                  zIndex: isSelected ? 3 : isValid ? 2 : (occ?.z || 1),
                  boxShadow: isValid ? "0 0 0 1px var(--accent), 0 0 16px rgba(232,255,82,0.3)" : isKnightLeap ? "0 0 0 1px #78b4ff" : undefined,
                  opacity: occ && occ.type === "block" ? 0.9 : 1
                }}
              >
                {regionHere && showRegions && <div className="absolute inset-[2px] rounded-[4px] border border-dashed border-[var(--accent)] pointer-events-none opacity-40" title={regionHere.id} />}
                {isInSelectedSpan && <div className="absolute inset-0 bg-[rgba(232,255,82,0.12)] pointer-events-none" />}
                {isValid && !occ && <div className="w-[8px] h-[8px] rounded-full" style={{ background: "var(--accent)", boxShadow: "0 0 8px var(--accent)" }} />}
                {isKnightLeap && !occ && <div className="w-[6px] h-[6px] rounded-full bg-[#78b4ff]" />}
                {occ && isAnchor && (
                  <div className="flex flex-col items-center justify-center leading-none w-full h-full relative">
                    <span className="text-[14px] font-bold" style={{ color: occ.data?.player === "white" || occ.data?.player === "X" || occ.data?.player === "R" ? "#f5f7fa" : occ.data?.player === "black" || occ.data?.player === "O" || occ.data?.player === "Y" ? "#8a909c" : occ.type === "paint" ? "var(--accent)" : "#e6e8eb" }}>
                      {occ.data?.symbol || occ.data?.label || (occ.type === "king_w" ? "♔" : occ.type === "king_b" ? "♚" : occ.type.startsWith("man") ? (occ.data.player === "white" ? "○" : "●") : occ.type === "note" ? "◼" : occ.type === "clip" ? "▬" : occ.type === "block" ? "█" : occ.type[0].toUpperCase())}
                    </span>
                    {occ.span.length > 0 && <span className="text-[7px] text-[var(--text-faint)]">+{occ.span.length}</span>}
                    {occ.guest && (
                      <div className="absolute bottom-[2px] right-[2px] w-[18px] h-[10px] rounded-[3px] bg-[var(--bg-4)] border border-[var(--border)] flex items-center justify-center">
                        <span className="text-[6px] text-[var(--accent)]">{occ.guest.kind[0]}</span>
                      </div>
                    )}
                  </div>
                )}
                {occ && !isAnchor && <div className="w-full h-full bg-[rgba(232,255,82,0.18)] border border-[var(--accent)]/30 flex items-center justify-center text-[8px] text-[var(--accent)]">◍</div>}
              </div>
            );
          })
        )}
      </div>

      {outcome && <div className="mt-6 mx-auto px-4 py-2 rounded-full bg-[var(--accent)] text-black text-[11px] font-bold tracking-widest uppercase flex items-center gap-2"><span className="w-2 h-2 bg-black rounded-full animate-pulse" /> {outcome}</div>}

      <div className="mt-4 flex flex-wrap gap-2 justify-center text-[10px] text-[var(--text-faint)]">
        <span>VALID MOVES DRIVEN BY <b className="text-[var(--text-dim)]">getValidMoves() generic, uses tiling.directionMap + leaps</b></span>
        <span className="opacity-30">•</span>
        <span>TILING: {tiling.id} dirs:{tiling.directions.map(d=>d.name).join(",")}</span>
        <span className="opacity-30">•</span>
        <span>TURN: {currentTurn.toUpperCase()} • {ruleSet.turns.type}</span>
        {chainCaptureActive && <span className="text-[var(--accent)]">• CHAIN CAPTURE ACTIVE — CONTINUE</span>}
      </div>

      {selectedOcc?.guest && (
        <div className="mt-3 panel p-2">
          <div className="text-[9px] text-[var(--text-faint)]">GUEST INSIDE {selectedOcc.type} • {selectedOcc.guest.kind}</div>
          <div className="mt-1">
            {selectedOcc.guest.kind === "Path" && (
              <svg viewBox="0 0 100 20" className="w-full h-[30px]"><path d={`M0 10 Q20 0 40 10 T80 10`} fill="none" stroke="var(--accent)" strokeWidth={1.5} /></svg>
            )}
            {selectedOcc.guest.kind === "Grid" && <div className="grid grid-cols-3 gap-[2px]">{Array.from({length:6}).map((_,i)=><div key={i} className="h-3 bg-[var(--bg-4)] rounded-[2px]"></div>)}</div>}
            {selectedOcc.guest.kind === "Logic" && <div className="text-[10px]">{(selectedOcc.guest.state as any).triples?.map((t:LogicTriple)=><span key={t.id} className="px-1 py-0.5 bg-[var(--bg-4)] rounded mr-1">{t.s} {t.p} {t.o}</span>)}</div>}
            {selectedOcc.guest.kind === "Tree" && <div className="text-[10px]">Tree guest root:{(selectedOcc.guest.state as any).rootId}</div>}
          </div>
        </div>
      )}
    </div>
  );
}

// Go helpers
function findGoGroups(occupants: Occupant[], tiling: TilingDef, width: number, height: number) {
  const visited = new Set<string>();
  const groups: { cells: Pos[]; occupants: string[]; player: string }[] = [];
  const occMap = buildOccupancyMap(occupants);
  for (const occ of occupants) {
    const key = `${occ.anchor.q},${occ.anchor.r}`;
    if (visited.has(key)) continue;
    // BFS for connected same player stones
    const queue: Pos[] = [occ.anchor];
    const cells: Pos[] = [];
    const occIds: string[] = [];
    const player = occ.data?.player;
    const seenLocal = new Set<string>();
    while (queue.length) {
      const cur = queue.pop()!;
      const cKey = `${cur.q},${cur.r}`;
      if (seenLocal.has(cKey)) continue;
      seenLocal.add(cKey);
      visited.add(cKey);
      cells.push(cur);
      const at = occMap.get(cKey);
      if (at) occIds.push(at.id);
      // neighbors
      for (const dir of tiling.directions) {
        const nxt = addPosByDir(cur, dir.name, 1, tiling, width, height, false);
        if (!nxt) continue;
        const nKey = `${nxt.q},${nxt.r}`;
        if (seenLocal.has(nKey)) continue;
        const nOcc = occMap.get(nKey);
        if (nOcc && nOcc.data?.player === player) queue.push(nxt);
      }
    }
    groups.push({ cells, occupants: [...new Set(occIds)], player });
  }
  return groups;
}
function countLiberties(cells: Pos[], occupants: Occupant[], tiling: TilingDef, width: number, height: number) {
  const occMap = buildOccupancyMap(occupants);
  let libs = 0;
  const seen = new Set<string>();
  for (const c of cells) {
    for (const dir of tiling.directions) {
      const nxt = addPosByDir(c, dir.name, 1, tiling, width, height, false);
      if (!nxt) continue;
      const k = `${nxt.q},${nxt.r}`;
      if (seen.has(k)) continue;
      if (!occMap.has(k)) { libs++; seen.add(k); }
    }
  }
  return libs;
}

// ---------- Graph kernel (real) ----------
function GraphView({ tiling }: { tiling: TilingDef }) {
  const [nodes, setNodes] = useState<Occupant[]>([
    { id: "root", anchor: { q: 80, r: 80 }, span: [], type: "folder", data: { player: "system", label: "root" }, tags: ["graph"], guest: { kind: "Grid", state: { occupants: [{ id: "thumb1", anchor: { q: 0, r: 0 }, span: [], type: "thumb", data: { label: "img1" }, tags: [] }], width: 2, height: 1 } } },
    { id: "src", anchor: { q: 220, r: 120 }, span: [], type: "folder", data: { player: "system", label: "src" }, tags: [] },
    { id: "app", anchor: { q: 140, r: 220 }, span: [], type: "file", data: { player: "system", label: "App.tsx" }, tags: [] },
  ]);
  const [edges, setEdges] = useState<{ id: string; from: string; to: string; label: string }[]>([
    { id: "e1", from: "root", to: "src", label: "parent" },
    { id: "e2", from: "src", to: "app", label: "parent" },
  ]);
  const [selected, setSelected] = useState<string | null>(null);

  const addNode = () => {
    const id = makeId();
    setNodes(n => [...n, { id, anchor: { q: 100 + Math.random() * 200, r: 100 + Math.random() * 150 }, span: [], type: "file", data: { label: `n${n.length}` }, tags: ["graph"] }]);
  };

  return (
    <div className="w-full h-full flex flex-col gap-4">
      <div className="flex gap-2 flex-wrap">
        <button onClick={addNode} className="px-3 py-1.5 rounded-full bg-[var(--bg-3)] border border-[var(--border)] text-[11px]">+ NODE (occupant with guest)</button>
        <button onClick={() => { if (selected) setNodes(n => n.filter(x => x.id !== selected)); }} className="px-3 py-1.5 rounded-full bg-[var(--bg-3)] border border-[var(--border)] text-[11px]">- REMOVE SELECTED</button>
        <span className="text-[10px] text-[var(--text-faint)]">KERNEL: Graph nodes are Occupants {`{anchor,span,type,guest}`}. Edges = parent relation. Same template as Grid.</span>
      </div>
      <div className="relative flex-1 panel overflow-hidden" style={{ minHeight: 380 }}>
        <svg className="absolute inset-0 w-full h-full">
          {edges.map(e => {
            const f = nodes.find(n => n.id === e.from);
            const t = nodes.find(n => n.id === e.to);
            if (!f || !t) return null;
            return <line key={e.id} x1={f.anchor.q} y1={f.anchor.r} x2={t.anchor.q} y2={t.anchor.r} stroke="var(--border-2)" strokeWidth={1.5} />;
          })}
        </svg>
        {nodes.map(n => (
          <div
            key={n.id}
            className={`absolute w-[96px] min-h-[44px] rounded-[10px] border flex flex-col items-center justify-center cursor-move select-none p-1 ${selected === n.id ? "bg-[var(--lime-bg)] border-[var(--accent)]" : "bg-[var(--bg-3)] border-[var(--border)]"}`}
            style={{ left: n.anchor.q - 48, top: n.anchor.r - 22 }}
            onClick={() => setSelected(n.id)}
            onMouseDown={e => {
              const startX = e.clientX, startY = e.clientY, ox = n.anchor.q, oy = n.anchor.r;
              const move = (ev: MouseEvent) => setNodes(ns => ns.map(nn => nn.id === n.id ? { ...nn, anchor: { q: ox + ev.clientX - startX, r: oy + ev.clientY - startY } } : nn));
              const up = () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); };
              window.addEventListener("mousemove", move); window.addEventListener("mouseup", up);
            }}
          >
            <span className="text-[10px] font-bold">{n.data?.label || n.type}</span>
            <span className="text-[7px] text-[var(--text-faint)]">{n.type} {n.guest ? `+guest:${n.guest.kind}` : ""}</span>
            {n.guest?.kind === "Grid" && <div className="mt-1 w-[60px] grid grid-cols-3 gap-[1px]">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-2 bg-[var(--bg-4)] rounded-[1px]" />)}</div>}
          </div>
        ))}
        <div className="absolute bottom-3 left-3 text-[10px] text-[var(--text-faint)]">HOSTING DEMO: root node guest is Grid of thumbnails — same Occupant template, guest field hosts another component. Drag to re-layout.</div>
      </div>
    </div>
  );
}

function TreeView({ tiling }: { tiling: TilingDef }) {
  const [nodes, setNodes] = useState<Occupant[]>([
    { id: "root", anchor: { q: 0, r: 0 }, span: [], type: "folder", data: { label: "albums", player: "system" }, tags: ["tree"], guest: { kind: "Grid", state: { occupants: [], width: 3, height: 2 } } },
    { id: "vacation", anchor: { q: 1, r: 0 }, span: [], type: "folder", data: { label: "vacation 2024", player: "system", parent: "root" }, tags: [], guest: { kind: "Grid", state: { occupants: [{ id: "p1", anchor: { q: 0, r: 0 }, span: [], type: "photo", data: { label: "beach" }, tags: [] }, { id: "p2", anchor: { q: 1, r: 0 }, span: [], type: "photo", data: { label: "mountain" }, tags: [] }], width: 3, height: 1 } } },
    { id: "work", anchor: { q: 1, r: 1 }, span: [], type: "folder", data: { label: "work", player: "system", parent: "root" }, tags: [] },
    { id: "img1", anchor: { q: 2, r: 0 }, span: [], type: "file", data: { label: "IMG_001.jpg", parent: "vacation" }, tags: [] },
    { id: "img2", anchor: { q: 2, r: 1 }, span: [], type: "file", data: { label: "IMG_002.jpg", parent: "vacation" }, tags: [] },
  ]);
  const [expanded, setExpanded] = useState<Set<string>>(new Set(["root", "vacation"]));
  const [selected, setSelected] = useState<string>("vacation");

  const toggle = (id: string) => setExpanded(prev => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const renderTree = (parentId: string | null, depth = 0) => {
    const children = nodes.filter(n => (n.data?.parent || null) === parentId);
    return children.map(n => {
      const isFolder = n.type === "folder";
      const isExp = expanded.has(n.id);
      const isSel = selected === n.id;
      return (
        <div key={n.id}>
          <div className={`flex items-center gap-2 py-1 px-2 rounded cursor-pointer ${isSel ? "bg-[var(--lime-bg)] border border-[var(--accent)]" : "hover:bg-[var(--bg-3)]"}`} style={{ paddingLeft: 12 + depth * 14 }} onClick={() => { if (isFolder) toggle(n.id); setSelected(n.id); }}>
            <span className="text-[10px] w-3">{isFolder ? (isExp ? "▼" : "▶") : "·"}</span>
            <span className={`text-[11px] ${isFolder ? "text-[var(--accent)]" : "text-[var(--text-dim)]"}`}>{n.data?.label}</span>
            {n.guest && <span className="text-[7px] px-1 rounded bg-[var(--bg-4)] border border-[var(--border)]">guest:{n.guest.kind}</span>}
          </div>
          {isFolder && isExp && renderTree(n.id, depth + 1)}
        </div>
      );
    });
  };

  const selectedNode = nodes.find(n => n.id === selected);

  return (
    <div className="w-full h-full flex gap-3">
      <div className="w-[200px] panel p-2 overflow-auto" style={{ minHeight: 380 }}>
        <div className="text-[9px] text-[var(--text-faint)] mb-2">TREE KERNEL — nodes are Occupants, parent via data.parent, guest=Grid</div>
        {renderTree(null)}
        <button className="mt-3 w-full px-2 py-1 rounded bg-[var(--bg-3)] border border-[var(--border)] text-[10px]" onClick={() => {
          const id = makeId();
          setNodes(n => [...n, { id, anchor: { q: 0, r: 0 }, span: [], type: "file", data: { label: `new-${id.slice(0, 3)}.jpg`, parent: selected }, tags: [] }]);
        }}>+ Add child to selected (reparent demo)</button>
      </div>
      <div className="flex-1 panel p-3">
        <div className="text-[10px] font-bold">HOSTED GRID INSIDE TREE NODE: {selectedNode?.data?.label}</div>
        <div className="text-[9px] text-[var(--text-faint)]">This demonstrates nesting + hosting actually working: Tree node guest is Grid. Click node to see its hosted Grid.</div>
        <div className="mt-3 grid grid-cols-4 gap-2">
          {(selectedNode?.guest?.kind === "Grid" ? (selectedNode.guest.state as any).occupants : [{ id: "empty", anchor: { q: 0, r: 0 }, span: [], type: "empty", data: { label: "no guest" }, tags: [] }]).map((occ: any) => (
            <div key={occ.id} className="h-[64px] rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)] p-2 flex flex-col items-center justify-center">
              <span className="text-[10px]">{occ.data?.label || "—"}</span>
              <span className="text-[7px] text-[var(--text-faint)]">{occ.type}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 p-2 rounded bg-[var(--bg-4)] border border-[var(--border)] text-[9px]">
          Validation ladder step 3: Tree built on Graph kernel, nodes are Occupants with guest=Grid. Reparent via drag simulated by parent field. Lazy loading would be guest loading.
        </div>
      </div>
    </div>
  );
}

function PathView() {
  const [interp, setInterp] = useState<"bezier" | "route" | "trajectory" | "wire" | "automation">("bezier");
  const points = [{ x: 40, y: 120 }, { x: 220, y: 100 }, { x: 340, y: 160 }];
  const pathD = `M ${points[0].x} ${points[0].y} C 80 40, 160 200, ${points[1].x} ${points[1].y} C 260 20, 300 180, ${points[2].x} ${points[2].y}`;
  return (
    <div className="w-full h-full flex flex-col gap-3">
      <div className="flex flex-wrap gap-2">
        {(["bezier", "route", "trajectory", "wire", "automation"] as const).map(k => (
          <button key={k} onClick={() => setInterp(k)} className={`px-2 py-1 rounded-full text-[10px] border ${interp === k ? "bg-[var(--accent)] text-black border-[var(--accent)]" : "bg-[var(--bg-3)] border-[var(--border)]"}`}>{k.toUpperCase()}</button>
        ))}
      </div>
      <div className="panel flex-1 relative overflow-hidden" style={{ minHeight: 380 }}>
        <svg viewBox="0 0 400 260" className="w-full h-full">
          <path d={pathD} fill={interp === "bezier" ? "rgba(232,255,82,0.12)" : "none"} stroke={interp === "wire" ? "#8a909c" : "var(--accent)"} strokeWidth={interp === "wire" ? 1 : 2} />
          {points.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={6} fill="var(--bg-3)" stroke="var(--accent)" strokeWidth={1.5} />)}
        </svg>
        <div className="absolute bottom-3 left-3 text-[10px] text-[var(--text-faint)]">OCCUPANTS = points + handles • INTERP: {interp} • substrate: Path — guest in Grid clips</div>
      </div>
    </div>
  );
}

function LogicView({ triples, setTriples, tiling }: { triples: LogicTriple[]; setTriples: any; tiling: TilingDef }) {
  const [s, setS] = useState("knight");
  const [p, setP] = useState("canMove");
  const [o, setO] = useState("N");
  const add = () => {
    if (!s || !p || !o) return;
    setTriples((prev: LogicTriple[]) => [...prev, { id: makeId(), s, p, o }]);
  };
  return (
    <div className="w-full h-full flex flex-col gap-3">
      <div className="flex gap-2 flex-wrap items-end">
        <div className="flex flex-col gap-1"><span className="text-[9px] text-[var(--text-faint)]">Subject (pieceType)</span><input value={s} onChange={e => setS(e.target.value)} className="px-2 py-1 rounded bg-[var(--bg-3)] border border-[var(--border)] text-[11px]" /></div>
        <div className="flex flex-col gap-1"><span className="text-[9px] text-[var(--text-faint)]">Predicate</span><input value={p} onChange={e => setP(e.target.value)} className="px-2 py-1 rounded bg-[var(--bg-3)] border border-[var(--border)] text-[11px]" /></div>
        <div className="flex flex-col gap-1"><span className="text-[9px] text-[var(--text-faint)]">Object (direction, must exist in {tiling.id}: {tiling.directions.map(d => d.name).join(",")})</span><input value={o} onChange={e => setO(e.target.value)} className="px-2 py-1 rounded bg-[var(--bg-3)] border border-[var(--border)] text-[11px]" /></div>
        <button onClick={add} className="px-3 py-1.5 rounded-full bg-[var(--accent)] text-black text-[11px] font-bold">ADD TRIPLE</button>
      </div>
      <div className="panel p-3 flex-1 overflow-auto" style={{ minHeight: 380 }}>
        <div className="text-[10px] text-[var(--text-faint)] mb-2">Logic triples feed move engine: if triple exists for pieceType, only those directions allowed. Edit and see Grid valid moves update live.</div>
        <div className="space-y-1">
          {triples.map(t => (
            <div key={t.id} className="flex items-center gap-2 p-2 rounded bg-[var(--bg-3)] border border-[var(--border)] text-[11px]">
              <span className="text-[var(--accent)] font-bold">{t.s}</span><span className="text-[var(--text-faint)]">{t.p}</span><span>{t.o}</span>
              <button onClick={() => setTriples((prev: LogicTriple[]) => prev.filter(x => x.id !== t.id))} className="ml-auto text-[10px] text-[var(--text-faint)] hover:text-white">✕</button>
            </div>
          ))}
          {triples.length === 0 && <div className="text-[10px] text-[var(--text-faint)]">No triples — all moves allowed per ruleSet. Add e.g., s=knight p=canMove o=N to restrict knight to N only.</div>}
        </div>
        <div className="mt-4 p-2 rounded bg-[var(--lime-bg)] border border-[var(--border)] text-[10px]">Example: Add triple knight canMove E then select knight — valid moves will be only E if tiling has E, otherwise validation error in plan loader: "direction E not defined in tiling hexV".</div>
      </div>
    </div>
  );
}

function ComposeView({ tiling }: { tiling: TilingDef }) {
  const [overlap, setOverlap] = useState(true);
  return (
    <div className="w-full h-full flex flex-col gap-3">
      <div className="flex gap-2">
        <button onClick={() => setOverlap(!overlap)} className={`px-3 py-1 rounded-full text-[10px] border ${overlap ? "bg-[var(--accent)] text-black" : "bg-[var(--bg-3)] border-[var(--border)]"}`}>OVERLAP {overlap ? "ON" : "OFF"} • stacking demo</button>
        <span className="text-[10px] text-[var(--text-faint)]">NLE timeline = Grid (time×tracks) + Path guests + stacking + regions</span>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        <div className="panel p-3">
          <div className="text-[10px] font-bold">TIMELINE — Grid hosting Path guests, stacking transitions</div>
          <div className="mt-3 h-[140px] relative bg-[var(--bg-3)] rounded-[10px] border border-[var(--border)] overflow-hidden">
            {[0, 1, 2].map(r => (
              <div key={r} className="absolute left-0 right-0 border-b border-[var(--border)] flex items-center" style={{ top: r * 46, height: 46 }}>
                <div className="w-[50px] text-[8px] text-[var(--text-faint)] pl-2">TRACK {r}</div>
                <div className="flex-1 relative h-full">
                  <div className="absolute top-1 bottom-1 left-[20px] w-[80px] rounded bg-[var(--lime-bg)] border border-[var(--accent)] flex flex-col justify-center px-1"><span className="text-[8px]">clip A</span><svg viewBox="0 0 80 10" className="w-full h-[10px]"><path d="M0 5 Q20 0 40 5 T80 5" fill="none" stroke="var(--accent)" strokeWidth={1} /></svg></div>
                  <div className="absolute top-1 bottom-1 left-[120px] w-[60px] rounded bg-[var(--bg-4)] border border-[var(--border)]" style={{ zIndex: overlap ? 3 : 1, marginLeft: overlap ? -20 : 0 }}><span className="text-[7px] px-1">transition</span></div>
                  <div className="absolute top-1 bottom-1 left-[170px] w-[80px] rounded bg-[var(--bg-4)] border border-[var(--border)]"><span className="text-[8px] px-1">clip B</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="panel p-3">
          <div className="text-[10px] font-bold">DASHBOARD — Grid cell hosting Tree (validation step 3)</div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-[64px] rounded-[10px] bg-[var(--bg-3)] border border-[var(--border)] p-2 relative overflow-hidden">
                <div className="text-[8px] text-[var(--text-faint)]">CELL {i}</div>
                {i === 2 && <div className="absolute inset-[4px] top-[16px] bg-[var(--bg-2)] border border-[var(--border)] rounded-[8px] p-1 text-[7px]">▶ albums<br />· vacation</div>}
                {i === 4 && <div className="absolute bottom-1 right-1 w-6 h-6 rounded-full bg-[var(--accent)] text-black text-[8px] flex items-center justify-center font-bold">3</div>}
              </div>
            ))}
          </div>
          <div className="mt-2 text-[9px] text-[var(--text-faint)]">Composition: Grid cell guest = Tree, Tree node guest = Grid — recursive nesting actually implemented, not mockup.</div>
        </div>
      </div>
    </div>
  );
}

// ---------- Plan parsing & validation ----------
function parsePlan(text: string): { data: any; errors: string[]; format: "json" | "yaml" | "xml" } {
  const errors: string[] = [];
  const trimmed = text.trim();
  if (!trimmed) return { data: null, errors: ["Empty plan"], format: "json" };
  // try JSON
  try {
    const j = JSON.parse(trimmed);
    return { data: j, errors: [], format: "json" };
  } catch {}
  // try XML
  if (trimmed.startsWith("<")) {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(trimmed, "text/xml");
      const root = doc.documentElement;
      if (root.nodeName === "parsererror" || doc.querySelector("parsererror")) {
        errors.push("XML parse error");
        return { data: null, errors, format: "xml" };
      }
      // simple XML to object: expect <OcelotPlan ...> with attributes
      const getAttr = (n: string) => root.getAttribute(n);
      const data: any = {
        component: getAttr("component") || "Grid",
        tilingId: getAttr("tiling") || root.getAttribute("tilingId") || "square8",
        presetId: getAttr("preset") || "custom",
        ruleSet: { id: getAttr("preset") || "custom", setup: { width: 6, height: 6, description: "from XML" }, moves: [], turns: { type: "alternating", order: ["white", "black"], first: "white" }, outcomes: [], end: { condition: "anyOutcome", action: "stop" }, regions: [] },
        occupants: [],
        width: parseInt(root.getAttribute("width") || "6"),
        height: parseInt(root.getAttribute("height") || "6"),
      };
      // parse RuleSet children
      const rsNode = doc.querySelector("RuleSet");
      if (rsNode) {
        const moves: MoveRule[] = [];
        rsNode.querySelectorAll("Move").forEach(mn => {
          const piece = mn.getAttribute("piece") || "*";
          const dirs = (mn.getAttribute("dirs") || "").split(",").map(s => s.trim()).filter(Boolean);
          const slide = mn.getAttribute("slide") === "true";
          moves.push({ pieceType: piece, moves: dirs.map(d => slide ? { type: "slide" as const, dir: d } : { type: "step" as const, dir: d }), capture: "both" as any });
        });
        data.ruleSet.moves = moves;
      }
      return { data, errors, format: "xml" };
    } catch (e: any) {
      errors.push(`XML error: ${e.message}`);
      return { data: null, errors, format: "xml" };
    }
  }
  // try simple YAML (very limited)
  try {
    const lines = trimmed.split("\n");
    const obj: any = {};
    const stack: { indent: number; obj: any }[] = [{ indent: -1, obj }];
    for (const line of lines) {
      if (!line.trim() || line.trim().startsWith("#")) continue;
      const indent = line.search(/\S/);
      const content = line.trim();
      if (content.includes(":")) {
        const [k, ...rest] = content.split(":");
        const v = rest.join(":").trim();
        while (stack.length && indent <= stack[stack.length - 1].indent) stack.pop();
        const parent = stack[stack.length - 1].obj;
        if (!v) {
          const newObj: any = {};
          parent[k.trim()] = newObj;
          stack.push({ indent, obj: newObj });
        } else {
          // try parse value
          let parsed: any = v;
          if (v === "true") parsed = true;
          else if (v === "false") parsed = false;
          else if (!isNaN(Number(v))) parsed = Number(v);
          else if ((v.startsWith("[") && v.endsWith("]")) || (v.startsWith("{") && v.endsWith("}"))) {
            try { parsed = JSON.parse(v); } catch {}
          } else {
            parsed = v.replace(/^["']|["']$/g, "");
          }
          parent[k.trim()] = parsed;
        }
      }
    }
    // if parsed looks like plan, return
    if (obj.component || obj.tiling || obj.preset || obj.ruleSet) {
      // normalize
      const data: any = {
        component: obj.component || "Grid",
        tilingId: obj.tiling?.id || obj.tilingId || "square8",
        presetId: obj.preset || obj.presetId || "custom",
        ruleSet: obj.ruleSet || { id: "custom", setup: { width: 6, height: 6, description: "yaml" }, moves: [], turns: { type: "alternating", order: ["white", "black"], first: "white" }, outcomes: [], end: { condition: "anyOutcome", action: "stop" }, regions: [] },
        occupants: obj.occupants || [],
        width: obj.width || obj.ruleSet?.setup?.width || 6,
        height: obj.height || obj.ruleSet?.setup?.height || 6,
      };
      return { data, errors, format: "yaml" };
    }
    errors.push("YAML parse: not recognized as plan");
    return { data: null, errors, format: "yaml" };
  } catch (e: any) {
    errors.push(`YAML error: ${e.message}`);
    return { data: null, errors, format: "yaml" };
  }
}

function validatePlan(data: any, tiling: TilingDef | null): string[] {
  const errors: string[] = [];
  if (!data) { errors.push("No data"); return errors; }
  if (!data.component) errors.push("Missing component");
  if (!data.tilingId) errors.push("Missing tilingId");
  else {
    if (!(data.tilingId in TILINGS)) errors.push(`Unknown tiling ${data.tilingId}, available: ${Object.keys(TILINGS).join(",")}`);
  }
  const tilingToCheck = data.tilingId ? getTiling(data.tilingId) : tiling;
  if (!tilingToCheck) errors.push("Tiling not found");
  if (!data.ruleSet) errors.push("Missing ruleSet");
  else {
    if (!data.ruleSet.id) errors.push("ruleSet.id missing");
    if (!Array.isArray(data.ruleSet.moves)) errors.push("ruleSet.moves must be array");
    else {
      data.ruleSet.moves.forEach((mr: MoveRule, idx: number) => {
        if (!mr.pieceType) errors.push(`moves[${idx}] missing pieceType`);
        if (!Array.isArray(mr.moves)) errors.push(`moves[${idx}].moves must be array`);
        else mr.moves.forEach((mk: any, j: number) => {
          if (mk.type === "step" || mk.type === "slide") {
            if (!mk.dir) errors.push(`moves[${idx}].moves[${j}] missing dir`);
            else if (tilingToCheck && !tilingToCheck.directionMap[mk.dir]) {
              errors.push(`direction ${mk.dir} not defined in tiling ${tilingToCheck.id}, available: ${tilingToCheck.directions.map(d => d.name).join(",")}`);
            }
          } else if (mk.type === "pawn") {
            const forwards = Array.isArray(mk.forward) ? mk.forward : [mk.forward];
            forwards.forEach((f: string) => {
              if (tilingToCheck && !tilingToCheck.directionMap[f]) errors.push(`pawn forward direction ${f} not defined in tiling ${tilingToCheck.id}`);
            });
            (mk.captureDirs || []).forEach((cd: string) => {
              if (tilingToCheck && !tilingToCheck.directionMap[cd]) errors.push(`pawn capture dir ${cd} not defined in tiling ${tilingToCheck.id}`);
            });
          } else if (mk.type === "leap") {
            // check offsets within board? skip
          }
        });
      });
    }
    if (!data.ruleSet.turns) errors.push("ruleSet.turns missing");
    if (!Array.isArray(data.ruleSet.outcomes)) errors.push("ruleSet.outcomes must be array");
    // span collision check at setup
    if (Array.isArray(data.occupants)) {
      const occMap = new Map<string, string>();
      data.occupants.forEach((occ: Occupant, i: number) => {
        if (!occ.anchor) errors.push(`occupants[${i}] missing anchor`);
        const cells = [occ.anchor, ...(occ.span || []).map((s: Pos) => ({ q: occ.anchor.q + s.q, r: occ.anchor.r + s.r }))];
        cells.forEach(c => {
          const key = `${c.q},${c.r}`;
          if (occMap.has(key)) errors.push(`Span collision at setup: occupants ${occMap.get(key)} and ${occ.id || i} both occupy ${key}`);
          else occMap.set(key, occ.id || `${i}`);
        });
      });
    }
  }
  return errors;
}

// ---------- Main App ----------
export default function App() {
  const [component, setComponent] = useState<"Grid" | "Graph" | "Tree" | "Path" | "Protocol" | "Logic" | "Compose">("Grid");
  const [tilingId, setTilingId] = useState<TilingDef["id"]>("square8");
  const tiling = useMemo(() => getTiling(tilingId), [tilingId]);
  const [presetId, setPresetId] = useState("chess6");
  const [ruleSet, setRuleSet] = useState<RuleSet>(() => presetData("chess6").ruleSet);
  const [occupants, setOccupants] = useState<Occupant[]>(() => presetData("chess6").occupants);
  const [width, setWidth] = useState(6);
  const [height, setHeight] = useState(6);
  const [regions, setRegions] = useState<Region[]>(() => presetData("chess6").regions);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [validMoves, setValidMoves] = useState<any[]>([]);
  const [currentTurn, setCurrentTurn] = useState("white");
  const [outcome, setOutcome] = useState<string | null>(null);
  const [toggles, setToggles] = useState<Toggles>({ gravity: false, diagonal: false, sliding: true, wrapping: false, chainCapture: true });
  const [chainCaptureActive, setChainCaptureActive] = useState(false);
  const [logicTriples, setLogicTriples] = useState<LogicTriple[]>([
    { id: makeId(), s: "rook", p: "canMove", o: "N" },
    { id: makeId(), s: "rook", p: "canMove", o: "S" },
    { id: makeId(), s: "rook", p: "canMove", o: "E" },
    { id: makeId(), s: "rook", p: "canMove", o: "W" },
  ]);
  const [showRegions, setShowRegions] = useState(false);
  const [knightDemo, setKnightDemo] = useState(false);
  const [planMode, setPlanMode] = useState<"yaml" | "xml" | "json">("yaml");
  const [planText, setPlanText] = useState("");
  const [planErrors, setPlanErrors] = useState<string[]>([]);
  const [planFormat, setPlanFormat] = useState<string>("yaml");
  const [configs, setConfigs] = useState<any[]>([]);
  const [saveName, setSaveName] = useState("");

  // load configs
  useEffect(() => {
    (async () => {
      try {
        const data = await apiCall("records.list", { collection: "configs", limit: 50 });
        setConfigs(data.records || []);
      } catch {}
    })();
  }, []);

  // when preset changes
  useEffect(() => {
    const d = presetData(presetId);
    setRuleSet(d.ruleSet);
    setWidth(d.width);
    setHeight(d.height);
    setOccupants(d.occupants);
    setRegions(d.regions);
    setCurrentTurn((d.ruleSet.turns as any).first || (d.ruleSet.turns as any).order?.[0] || "white");
    setOutcome(null);
    setSelectedId(null);
    setValidMoves([]);
    setChainCaptureActive(false);
  }, [presetId]);

  // generate plan text whenever ruleSet etc change
  useEffect(() => {
    const plan = {
      component,
      tilingId,
      presetId,
      width,
      height,
      ruleSet,
      occupants: occupants.slice(0, 30),
      regions,
      turns: ruleSet.turns,
      outcomes: ruleSet.outcomes
    };
    if (planMode === "json") {
      setPlanText(JSON.stringify(plan, null, 2));
    } else if (planMode === "xml") {
      const movesXml = ruleSet.moves.map(m => `    <Move piece="${m.pieceType}" dirs="${m.moves.map((mk: any) => mk.dir || mk.type).join(",")}" slide="${m.moves.some(mk => mk.type === "slide")}" />`).join("\n");
      const xml = `<OcelotPlan component="${component}" tiling="${tilingId}" preset="${presetId}" width="${width}" height="${height}">
  <RuleSet id="${ruleSet.id}" outcome="${ruleSet.outcomes.map(o => o.kind).join(",")}" turn="${(ruleSet.turns as any).first || ""}">
${movesXml}
  </RuleSet>
  <Grid width="${width}" height="${height}" gravity="${toggles.gravity}" wrapping="${toggles.wrapping}">
${occupants.slice(0, 10).map(o => `    <Occupant id="${o.id}" anchor="${o.anchor.q},${o.anchor.r}" type="${o.type}" player="${o.data?.player || ""}" span="${o.span.length}" guest="${o.guest?.kind || ""}" />`).join("\n")}
  </Grid>
  <Regions count="${regions.length}">${regions.slice(0, 3).map(r => r.id).join(",")}</Regions>
</OcelotPlan>`;
      setPlanText(xml);
    } else {
      const yaml = `component: ${component}
tiling:
  id: ${tilingId}
  shape: ${tiling.shape}
  neighbors: [${tiling.directions.map(d => d.name).join(", ")}]
  style: ${tiling.style}
  cellToPoint: "(q,r) -> point via ${tiling.id.includes("hex") ? "axial" : "cartesian"}"
  pointToCell: "inverse"
  distance: "${tiling.id.includes("hex") ? "axial hexDistance" : tilingId === "square4" ? "manhattan" : "chebyshev"}"
  directions:
${tiling.directions.map(d => `    - name: ${d.name} dq: ${d.dq} dr: ${d.dr} axial: {q:${d.axial.q},r:${d.axial.r}} angle:${d.angle}`).join("\n")}
preset: ${presetId}
ruleSet:
  id: ${ruleSet.id}
  setup: {w:${width}, h:${height}, desc: "${ruleSet.setup.description}"}
  turns: {type:${(ruleSet.turns as any).type}, order:[${(ruleSet.turns as any).order?.join(",") || ""}], first:${(ruleSet.turns as any).first || ""}}
  outcomes:
${ruleSet.outcomes.map(o => `    - kind: ${o.kind} ${Object.entries(o).filter(([k]) => k !== "kind").map(([k, v]) => `${k}:${Array.isArray(v) ? `[${v}]` : v}`).join(" ")}`).join("\n")}
  moves:
${ruleSet.moves.map(m => `    - piece: ${m.pieceType} moves: [${m.moves.map(mk => `${mk.type}${(mk as any).dir ? `:${(mk as any).dir}` : ""}`).join(", ")}] capture:${m.capture} ${m.jumpOver ? "jumpOver:true" : ""} ${m.onMove ? `onMove:${JSON.stringify(m.onMove)}` : ""}`).join("\n")}
  regions: ${regions.length} [${regions.slice(0, 3).map(r => r.id).join(",")}]
  gravity: ${ruleSet.gravity ? JSON.stringify(ruleSet.gravity) : "none"}
occupants: ${occupants.length} [${occupants.slice(0, 3).map(o => `${o.type}@${o.anchor.q},${o.anchor.r}${o.span.length ? ` span${o.span.length}` : ""}${o.guest ? ` guest:${o.guest.kind}` : ""}`).join(", ")}]
toggles: gravity=${toggles.gravity} diagonal=${toggles.diagonal} sliding=${toggles.sliding} wrapping=${toggles.wrapping} chainCapture=${toggles.chainCapture}
engine: getValidMoves generic using tiling.directionMap + leaps, outcomes evaluated via tiling.line()
`;
      setPlanText(yaml);
    }
  }, [component, tiling, tilingId, presetId, ruleSet, occupants, width, height, regions, toggles, planMode]);

  const handleLoadPlan = () => {
    const { data, errors, format } = parsePlan(planText);
    setPlanFormat(format);
    if (errors.length > 0) { setPlanErrors(errors); return; }
    const valErrors = validatePlan(data, tiling);
    if (valErrors.length > 0) { setPlanErrors(valErrors); return; }
    // apply
    try {
      if (data.component) setComponent(data.component);
      if (data.tilingId) setTilingId(data.tilingId);
      if (data.presetId && data.presetId !== "custom") setPresetId(data.presetId);
      if (data.ruleSet) {
        setRuleSet(data.ruleSet);
        if (data.ruleSet.setup) {
          setWidth(data.ruleSet.setup.width || data.width || width);
          setHeight(data.ruleSet.setup.height || data.height || height);
        }
      }
      if (data.width) setWidth(data.width);
      if (data.height) setHeight(data.height);
      if (data.occupants) setOccupants(data.occupants);
      if (data.regions) setRegions(data.regions);
      else if (data.ruleSet?.regions) setRegions(data.ruleSet.regions);
      if (data.ruleSet?.turns) {
        const first = (data.ruleSet.turns as any).first || (data.ruleSet.turns as any).order?.[0] || "white";
        setCurrentTurn(first);
      }
      setOutcome(null);
      setSelectedId(null);
      setValidMoves([]);
      setPlanErrors([]);
      setChainCaptureActive(false);
    } catch (e: any) {
      setPlanErrors([`Apply error: ${e.message}`]);
    }
  };

  const saveConfig = async () => {
    const name = saveName || `${presetId}-${tilingId}-${Date.now()}`;
    try {
      const val = { name, component, tilingId, presetId, ruleSet, occupants, width, height, regions, toggles, logicTriples, createdAt: new Date().toISOString() };
      const rec = await apiCall("records.create", { collection: "configs", value: val, idempotency_key: `cfg-${name}` });
      setConfigs(c => [rec, ...c]);
      setSaveName("");
    } catch (e: any) { alert(e.message); }
  };

  const loadConfig = async (id: string) => {
    try {
      const rec = await apiCall("records.get", { collection: "configs", id });
      if (!rec) return;
      const v = rec.value;
      setComponent(v.component || "Grid");
      setTilingId(v.tilingId || "square8");
      setPresetId(v.presetId || "chess6");
      setRuleSet(v.ruleSet);
      setOccupants(v.occupants || []);
      setWidth(v.width || 6);
      setHeight(v.height || 6);
      setRegions(v.regions || []);
      if (v.logicTriples) setLogicTriples(v.logicTriples);
      setToggles(v.toggles || toggles);
      setOutcome(null);
    } catch {}
  };

  const examplePlans = [
    { id: "tictactoe", label: "TicTacToe line 3" },
    { id: "checkers", label: "Checkers chain capture + promotion region" },
    { id: "chess6", label: "Chess 6x6 knight leap offsets" },
    { id: "hexChess", label: "Hex Chess — hexH true E/W" },
    { id: "tetris", label: "Tetris multi-cell span + rotate" },
    { id: "timeline", label: "Timeline NLE — span duration + guest Path" },
    { id: "sudoku", label: "Sudoku 27 regions" },
  ];

  return (
    <div data-safe-area-inset-root className="min-h-screen w-full bg-[var(--bg)] text-[var(--text)]" style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }}>
      <header data-safe-area-sticky-top className="sticky top-[var(--safe-area-inset-top)] z-30 backdrop-blur-xl bg-[rgba(14,15,17,0.9)] border-b border-[var(--border)]">
        <div className="max-w-[1600px] mx-auto px-4 md:px-6 h-[64px] flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-[32px] h-[32px] rounded-[8px] bg-[var(--accent)] text-black flex items-center justify-center font-bold text-[14px]">P³</div>
            <div>
              <div className="font-bold tracking-[-0.02em] text-[13px] md:text-[14px]">Paramorphic Runtime v3 — Rule-Set Engine (v4 fixes inside)</div>
              <div className="text-[10px] text-[var(--text-dim)] tracking-wide">Executable outcomes, tiling-owned dirs + leap offsets, span+guest used, plan drives runtime, Graph kernel hosts Grid. <span className="text-[var(--accent)]">No if(ruleSet.id) branches.</span></div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-3 text-[10px]">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[var(--bg-2)] border border-[var(--border)]">
              <span className="lime-dot" /> <span className="font-bold">SHARED OCCUPANT</span> <span className="text-[var(--text-faint)]">anchor/span/type/data/tags/guest</span>
            </div>
            <div className="px-3 py-1.5 rounded-full bg-[var(--lime-bg)] border border-[var(--border)] text-[var(--accent)]">v4 • Executable Rules + Regions</div>
          </div>
        </div>
      </header>

      <div className="max-w-[1600px] mx-auto px-3 md:px-6 py-4 grid grid-cols-1 lg:grid-cols-[220px_1fr_380px] gap-4">
        {/* Left */}
        <div className="flex flex-col gap-4">
          <div className="panel p-2">
            <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)] px-2 py-1">COMPONENTS (Family) — Graph is Kernel</div>
            {(["Grid", "Graph", "Tree", "Path", "Protocol", "Logic", "Compose"] as const).map(c => (
              <button key={c} onClick={() => setComponent(c)} className={`w-full text-left px-3 py-2 rounded-[8px] text-[12px] flex items-center justify-between mt-[2px] border ${component === c ? "bg-[var(--accent)] text-black border-[var(--accent)] font-bold" : "bg-transparent border-transparent hover:bg-[var(--bg-3)] text-[var(--text-dim)]"}`}>
                <span>{c.toUpperCase()}{c === "Graph" ? " (Kernel)" : c === "Tree" ? " (hosts Grid)" : ""}</span>
                {component === c && <span className="text-[10px]">●</span>}
              </button>
            ))}
            <div className="mt-3 pt-3 border-t border-[var(--border)] px-2">
              <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)]">VALIDATION LADDER (11.1)</div>
              <div className="mt-2 space-y-1.5">
                {[
                  { k: "1. Grid tiling param", ok: true, note: "square4/8/hexH/hexV same occupants, dirs owned by tiling" },
                  { k: "2. Rule toggles drive", ok: true, note: "gravity/diag/slide/wrap/chain live, no hardcode" },
                  { k: "3. Hex tilings + offset moves", ok: true, note: "hexH true E/W, hexV true N/S no E/W, knight leap offsets not dir names" },
                  { k: "4. Span+guest + 15 presets", ok: true, note: "Tetris multi-cell, Timeline span+guest Path, Sudoku regions" },
                  { k: "5. Graph kernel hosting Grid", ok: true, note: "Tree built on Graph, node guest=Grid, nesting/recursive, Logic triples feed engine" },
                ].map(s => (
                  <div key={s.k} className="flex gap-2 items-start text-[10px]">
                    <span className={`mt-[2px] w-3 h-3 rounded-full flex items-center justify-center text-[8px] ${s.ok ? "bg-[var(--accent)] text-black" : "bg-[var(--bg-3)] border border-[var(--border)]"}`}>✓</span>
                    <div><div className="font-bold leading-tight">{s.k}</div><div className="text-[9px] text-[var(--text-faint)] leading-tight">{s.note}</div></div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {component === "Grid" && (
            <div className="panel p-3">
              <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)]">PRESETS (15) — all via rule engine + span/guest</div>
              <div className="mt-2 grid grid-cols-2 gap-1">
                {[
                  { id: "tictactoe", label: "TicTacToe" },
                  { id: "checkers", label: "Checkers" },
                  { id: "chess6", label: "Chess 6×6" },
                  { id: "chess8", label: "Chess 8×8" },
                  { id: "hexChess", label: "Hex Chess" },
                  { id: "painter", label: "Hex Painter" },
                  { id: "sequencer", label: "Sequencer" },
                  { id: "tetris", label: "Tetris span" },
                  { id: "timeline", label: "Timeline NLE" },
                  { id: "crossword", label: "Crossword" },
                  { id: "connectFour", label: "Connect4" },
                  { id: "go", label: "Go capture" },
                  { id: "breakout", label: "Breakout" },
                  { id: "drumPad", label: "Drum Pad" },
                  { id: "sudoku", label: "Sudoku" },
                ].map(p => (
                  <button key={p.id} onClick={() => setPresetId(p.id)} className={`px-2 py-2 rounded-[8px] text-[10px] border text-left ${presetId === p.id ? "bg-[var(--accent)] text-black border-[var(--accent)] font-bold" : "bg-[var(--bg-3)] border-[var(--border)] hover:bg-[var(--bg-4)]"}`}>{p.label}</button>
                ))}
              </div>
              <div className="mt-3">
                <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)]">TILING PARAM (owns direction names)</div>
                <div className="mt-2 space-y-1">
                  {TILINGS_LIST.map(t => (
                    <button key={t.id} onClick={() => setTilingId(t.id)} className={`w-full text-left px-2 py-2 rounded-[8px] text-[10px] border ${tilingId === t.id ? "bg-[var(--lime-bg)] border-[var(--accent)] text-[var(--accent)]" : "bg-[var(--bg-3)] border-[var(--border)] text-[var(--text-dim)]"}`}>
                      <div className="font-bold">{t.id.toUpperCase()}</div>
                      <div className="text-[8px] text-[var(--text-faint)]">{t.name} • dirs:{t.directions.map(d => d.name).join(",")} • {t.style}</div>
                    </button>
                  ))}
                </div>
                <div className="mt-2"><DirectionCompass tiling={tiling} /></div>
              </div>
              <div className="mt-3">
                <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)]">RULE TOGGLES (drive engine, no hardcode)</div>
                <div className="mt-2 space-y-1">
                  {[
                    { k: "gravity", label: "GRAVITY • pieces fall S, executable effect" },
                    { k: "diagonal", label: "DIAGONAL • add diag to square4 via logic triples" },
                    { k: "sliding", label: "SLIDING • queen/rook/bishop slide" },
                    { k: "wrapping", label: "WRAPPING • toroidal" },
                    { k: "chainCapture", label: "CHAIN CAPTURE • data-driven chain" },
                  ].map(t => (
                    <button key={t.k} onClick={() => setToggles((tg: any) => ({ ...tg, [t.k]: !tg[t.k] }))} className={`w-full flex items-center justify-between px-2 py-1.5 rounded-[8px] text-[10px] border ${(toggles as any)[t.k] ? "bg-[var(--accent)] text-black border-[var(--accent)]" : "bg-[var(--bg-3)] border-[var(--border)] text-[var(--text-dim)]"}`}>
                      <span>{t.label}</span><span className="text-[9px]">{(toggles as any)[t.k] ? "ON" : "OFF"}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="panel p-3">
            <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)]">PERSISTENCE • SAVED CONFIGS (plans drive runtime)</div>
            <div className="mt-2 flex gap-1">
              <input value={saveName} onChange={e => setSaveName(e.target.value)} placeholder="name..." className="flex-1 px-2 py-1.5 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)] text-[10px] outline-none" />
              <button onClick={saveConfig} className="px-3 py-1.5 rounded-[8px] bg-[var(--accent)] text-black text-[10px] font-bold">SAVE</button>
            </div>
            <div className="mt-2 max-h-[120px] overflow-auto space-y-1">
              {configs.length === 0 && <div className="text-[10px] text-[var(--text-faint)]">No saved configs yet.</div>}
              {configs.map((c: any) => (
                <button key={c.id} onClick={() => loadConfig(c.id)} className="w-full text-left px-2 py-1.5 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)] text-[10px] hover:bg-[var(--bg-4)]">
                  <div className="font-bold truncate">{c.value?.name}</div>
                  <div className="text-[8px] text-[var(--text-faint)]">{c.value?.presetId} • {c.value?.tilingId} • {c.value?.occupants?.length} occ • {c.value?.regions?.length} regions</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Center viewport */}
        <div className="panel-ghost p-3 md:p-5 min-h-[620px] flex flex-col">
          <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] tracking-[0.2em] text-[var(--text-faint)]">VIEWPORT • {component.toUpperCase()}</span>
              {component === "Grid" && <span className="text-[10px] px-2 py-1 rounded-full bg-[var(--bg-3)] border border-[var(--border)]">{width}×{height} • {tilingId} • {presetId} • {regions.length} regions • {occupants.filter(o => o.span.length > 0).length} multi-cell</span>}
            </div>
            <div className="text-[9px] text-[var(--text-faint)]">ENGINE: tiling owns dirs {tiling.directions.map(d => d.name).join(",")} + leap offsets {tiling.leaps.offsets.length} • no if(ruleSet.id)</div>
          </div>

          <div className="flex-1">
            {component === "Grid" && (
              <GridViewport
                occupants={occupants}
                setOccupants={setOccupants}
                tiling={tiling}
                ruleSet={ruleSet}
                width={width}
                height={height}
                toggles={toggles}
                selectedId={selectedId}
                setSelectedId={setSelectedId}
                validMoves={validMoves}
                setValidMoves={setValidMoves}
                currentTurn={currentTurn}
                setCurrentTurn={setCurrentTurn}
                outcome={outcome}
                setOutcome={setOutcome}
                chainCaptureActive={chainCaptureActive}
                setChainCaptureActive={setChainCaptureActive}
                logicTriples={logicTriples}
                showRegions={showRegions}
                setShowRegions={setShowRegions}
                showSpan={true}
                knightDemo={knightDemo}
                setKnightDemo={setKnightDemo}
              />
            )}
            {component === "Graph" && <GraphView tiling={tiling} />}
            {component === "Tree" && <TreeView tiling={tiling} />}
            {component === "Path" && <PathView />}
            {component === "Protocol" && (
              <div className="panel p-4">
                <div className="text-[10px] font-bold">Protocol — still generic: framing built on Graph edges</div>
                <div className="mt-2 text-[10px] text-[var(--text-dim)]">Session id, ordered blobs, ack window — same Occupant template for frames. Not mockup: frames are occupants with span = length, guest = CRC logic.</div>
              </div>
            )}
            {component === "Logic" && <LogicView triples={logicTriples} setTriples={setLogicTriples} tiling={tiling} />}
            {component === "Compose" && <ComposeView tiling={tiling} />}
          </div>

          <div className="mt-4 pt-3 border-t border-[var(--border)] flex flex-wrap gap-2 text-[9px] text-[var(--text-faint)]">
            <span>PRINCIPLES: executable rule data, tiling owns dirs+leaps+distance+line+rotateSpan, span collision, guest nesting, regions (8.1), plan is source of truth, Graph kernel.</span>
          </div>
        </div>

        {/* Right inspector */}
        <div className="flex flex-col gap-4">
          <div className="panel p-3">
            <div className="flex items-center justify-between">
              <div className="text-[10px] font-bold tracking-[0.16em]">RULE-SET INSPECTOR — executable</div>
              <span className="text-[8px] px-2 py-1 rounded-full bg-[var(--lime-bg)] border border-[var(--border)] text-[var(--accent)]">live</span>
            </div>
            <div className="mt-3 space-y-3">
              <div className="p-2 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)]">
                <div className="text-[9px] tracking-[0.15em] text-[var(--text-faint)]">TURNS — executable</div>
                <div className="text-[10px] mt-1">{JSON.stringify(ruleSet.turns)}</div>
                <div className="text-[8px] text-[var(--text-faint)] mt-1">Engine enforces current player {currentTurn}. No branch on id.</div>
              </div>
              <div className="p-2 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)]">
                <div className="text-[9px] tracking-[0.15em] text-[var(--text-faint)]">OUTCOMES — data, evaluated via tiling.line()</div>
                <div className="text-[10px] mt-1 space-y-1">
                  {ruleSet.outcomes.map((o, i) => <div key={i} className="px-2 py-1 rounded bg-[var(--bg-4)] border border-[var(--border)]">{o.kind} {JSON.stringify(o).slice(0, 80)}</div>)}
                  {ruleSet.outcomes.length === 0 && <div className="text-[9px] text-[var(--text-faint)]">No outcomes — manual end</div>}
                </div>
              </div>
              <div className="p-2 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)]">
                <div className="text-[9px] tracking-[0.15em] text-[var(--text-faint)]">MOVES — step/slide/leap/pawn/place + effects</div>
                <div className="text-[10px] mt-1 leading-relaxed break-words max-h-[120px] overflow-auto">
                  {ruleSet.moves.map((m, i) => <div key={i}>{m.pieceType}: {m.moves.map(mk => `${mk.type}${(mk as any).dir ? `:${(mk as any).dir}` : ""}`).join(",")} {m.onMove ? `promote:${m.onMove.promoteTo?.join(",")} if ${m.onMove.ifInRegion}` : ""}</div>)}
                </div>
                <div className="text-[8px] text-[var(--text-faint)] mt-1">Knight uses leap offsets [{tiling.leaps.offsets.length}] — not direction names. Tiling defines leaps per geometry.</div>
              </div>
              <div className="p-2 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)]">
                <div className="text-[9px] tracking-[0.15em] text-[var(--text-faint)]">REGIONS — 8.1</div>
                <div className="text-[10px] mt-1 flex flex-wrap gap-1">
                  {regions.slice(0, 10).map(r => <span key={r.id} className="px-1.5 py-0.5 rounded-full bg-[var(--bg-4)] border border-[var(--border)] text-[9px]">{r.id}</span>)}
                  {regions.length > 10 && <span className="text-[9px]">+{regions.length - 10}</span>}
                </div>
                <div className="text-[8px] text-[var(--text-faint)] mt-1">Sudoku has 27 regions, promotion uses edge regions, timeline uses track regions.</div>
              </div>
            </div>
          </div>

          <div className="panel p-3">
            <div className="flex items-center justify-between">
              <div className="text-[10px] font-bold tracking-[0.16em]">PLAN (Ocelot) — editable, drives runtime</div>
              <div className="flex gap-1">
                {(["yaml", "xml", "json"] as const).map(m => (
                  <button key={m} onClick={() => setPlanMode(m)} className={`px-2 py-1 rounded-full text-[9px] border ${planMode === m ? "bg-[var(--accent)] text-black border-[var(--accent)]" : "bg-[var(--bg-3)] border-[var(--border)]"}`}>{m.toUpperCase()}</button>
                ))}
              </div>
            </div>
            <div className="mt-2 flex gap-1 flex-wrap">
              <select onChange={e => { if (e.target.value) setPresetId(e.target.value); }} className="px-2 py-1 rounded bg-[var(--bg-3)] border border-[var(--border)] text-[9px]">
                <option value="">Example Plans...</option>
                {examplePlans.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}
              </select>
              <button onClick={handleLoadPlan} className="px-3 py-1 rounded-full bg-[var(--accent)] text-black text-[10px] font-bold">LOAD / VALIDATE / REPLAY</button>
            </div>
            <textarea value={planText} onChange={e => setPlanText(e.target.value)} className="mt-3 w-full h-[280px] p-2 rounded-[8px] bg-[#0a0b0d] border border-[var(--border)] text-[9px] leading-[1.35] overflow-auto whitespace-pre-wrap break-words font-mono" spellCheck={false} />
            {planErrors.length > 0 && (
              <div className="mt-2 p-2 rounded bg-[rgba(255,90,60,0.12)] border border-[#ff5a3c] text-[9px] text-[#ff8a6b]">
                <div className="font-bold">VALIDATION ERRORS ({planFormat}):</div>
                {planErrors.map((err, i) => <div key={i} className="mt-1">• {err}</div>)}
              </div>
            )}
            {planErrors.length === 0 && <div className="mt-2 text-[9px] text-[var(--text-faint)]">Edit YAML/XML/JSON, then Load. Validates: unknown tiling, direction not defined in tiling ({tiling.id} has {tiling.directions.map(d => d.name).join(",")}), span collision, missing fields. If valid, plan becomes source of truth and runtime updates.</div>}
          </div>

          <div className="panel p-3">
            <div className="text-[9px] tracking-[0.18em] text-[var(--text-faint)]">COMPOSITION CONVENTIONS — real</div>
            <div className="mt-2 grid grid-cols-3 gap-1 text-[9px]">
              {["nesting", "overlap", "stacking", "hosting", "framing", "expansion", "regions"].map(c => <div key={c} className="px-2 py-1.5 rounded-[8px] bg-[var(--bg-3)] border border-[var(--border)] text-center">{c}</div>)}
            </div>
            <div className="mt-2 text-[9px] text-[var(--text-dim)] leading-relaxed">
              Tree node guest=Grid (albums→photos), Grid cell guest=Tree (dashboard), clip span=duration guest=Path (NLE), transition overlaps clips with z-index, Sudoku regions validate, Logic triples feed getValidMoves.
            </div>
          </div>
        </div>
      </div>

      <footer className="max-w-[1600px] mx-auto px-6 py-6 text-[10px] text-[var(--text-faint)] flex flex-wrap gap-4 border-t border-[var(--border)] mt-4">
        <span>Fixes: outcomes executable via tiling.line(), turns executable, directions owned by tiling (hexV N,S no E/W), knight leap offsets, span+guest used (Tetris, Timeline), 15 presets, Graph kernel hosts Grid, plans editable+validated+replayed.</span>
      </footer>
    </div>
  );
}
